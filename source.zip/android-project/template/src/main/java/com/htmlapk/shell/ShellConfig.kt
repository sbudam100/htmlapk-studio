package com.htmlapk.shell

import android.content.Context
import android.graphics.Color
import org.json.JSONObject

/**
 * Typed view of assets/config.json. Key names MUST match ConfigWriter in the :app module.
 * Every key is optional and has a safe default, so a partially written config never crashes the shell.
 */
class ShellConfig(private val root: JSONObject) {

    class Splash(o: JSONObject?) {
        private val j = o ?: JSONObject()
        val enabled = j.optBoolean("enabled", false)
        val backgroundColor = parseColor(j.optString("backgroundColor"), 0xFF0F172A.toInt())
        val loaderColor = parseColor(j.optString("loaderColor"), 0xFF00E5CC.toInt())
        val loaderStyle: String = j.optString("loaderStyle", "ring")
        val iconSizeDp = j.optInt("iconSizeDp", 120)
        val iconCornerDp = j.optInt("iconCornerDp", 16)
        val loaderSizeDp = j.optInt("loaderSizeDp", 48)
        val spacingDp = j.optInt("spacingDp", 28)
        val durationMs = j.optInt("durationMs", 2000).toLong()
        val thicknessDp = j.optInt("thicknessDp", 4)
        val fadeMs = j.optInt("fadeMs", 400).toLong()
        /** Asset path of a custom splash image, or empty to use the launcher icon. */
        val imageAsset: String = j.optString("imageAsset", "")
    }

    class Navigation(o: JSONObject?) {
        private val j = o ?: JSONObject()
        val pullToRefresh = j.optBoolean("pullToRefresh", false)
        val noInternetDialog = j.optBoolean("noInternetDialog", false)
        val loadingIndicator = j.optBoolean("loadingIndicator", false)
        val backHistory = j.optBoolean("backHistory", true)
        val exitConfirm = j.optBoolean("exitConfirm", true)
        val apiOnlyOwnPages = j.optBoolean("apiOnlyOwnPages", true)
    }

    class Web(o: JSONObject?) {
        private val j = o ?: JSONObject()
        val javaScript = j.optBoolean("javaScript", true)
        val domStorage = j.optBoolean("domStorage", true)
        val fileAccess = j.optBoolean("fileAccess", false)
        val contentAccess = j.optBoolean("contentAccess", false)
        val universalFileAccess = j.optBoolean("universalFileAccess", false)
        val fileAccessFromFileUrls = j.optBoolean("fileAccessFromFileUrls", false)
        val builtInZoom = j.optBoolean("builtInZoom", true)
        val wideViewport = j.optBoolean("wideViewport", true)
        val overviewMode = j.optBoolean("overviewMode", true)
        val geolocation = j.optBoolean("geolocation", false)
        val cacheMode: String = j.optString("cacheMode", "default")
        val mixedContent: String = j.optString("mixedContent", "compatibility")
    }

    val appName: String = root.optString("appName", "Web App")
    val packageName: String = root.optString("packageName", "")
    val versionName: String = root.optString("versionName", "1.0")
    val versionCode: Int = root.optInt("versionCode", 1)

    /** "html" | "zip" | "url" */
    val sourceType: String = root.optString("sourceType", "html")
    val entryFile: String = root.optString("entryFile", "index.html").trimStart('/')
    val startUrl: String = root.optString("startUrl", "")

    /** "portrait" | "landscape" | "auto" */
    val orientation: String = root.optString("orientation", "portrait")
    val statusBarVisible = root.optBoolean("statusBarVisible", true)
    val actionBarVisible = root.optBoolean("actionBarVisible", false)
    val keepScreenOn = root.optBoolean("keepScreenOn", false)
    val cutout = root.optBoolean("cutout", false)
    val desktopMode = root.optBoolean("desktopMode", false)

    /** "auto" | "night" | "day" */
    val themeMode: String = root.optString("themeMode", "auto")
    val barColor = parseColor(root.optString("barColor"), 0xFF2196F3.toInt())
    val loadingBackground = parseColor(root.optString("loadingBackground"), Color.WHITE)
    val customScheme: String = root.optString("customScheme", "")

    val declaredPermissions: List<String> = buildList {
        val arr = root.optJSONArray("declaredPermissions")
        if (arr != null) for (i in 0 until arr.length()) add(arr.optString(i))
    }

    val splash = Splash(root.optJSONObject("splash"))
    val navigation = Navigation(root.optJSONObject("navigation"))
    val web = Web(root.optJSONObject("webview"))

    /** The page that is loaded at start (https://appassets.androidplatform.net/... for bundled content). */
    fun resolveStartUrl(): String =
        if (sourceType == "url" && startUrl.isNotBlank()) startUrl
        else "$ASSET_ORIGIN/assets/www/$entryFile"

    val isRemote: Boolean get() = sourceType == "url"

    companion object {
        const val ASSET_HOST = "appassets.androidplatform.net"
        const val ASSET_ORIGIN = "https://$ASSET_HOST"

        fun load(context: Context): ShellConfig = try {
            val text = context.assets.open("config.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            ShellConfig(JSONObject(text))
        } catch (e: Exception) {
            ShellConfig(JSONObject())
        }

        fun parseColor(value: String?, fallback: Int): Int = try {
            if (value.isNullOrBlank()) fallback else Color.parseColor(value)
        } catch (e: IllegalArgumentException) {
            fallback
        }
    }
}
