package com.htmlapk.shell

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/** Full-screen splash drawn from config.splash: logo, spacing and a ring/bar loader, with a fade-out. */
class SplashOverlay(
    context: Context,
    private val cfg: ShellConfig.Splash,
    logo: Drawable?
) : FrameLayout(context) {

    private var dismissed = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    init {
        setBackgroundColor(cfg.backgroundColor)
        isClickable = true
        isFocusable = true

        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        addView(column, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        if (logo != null) {
            val radius = dp(cfg.iconCornerDp).toFloat()
            val image = ImageView(context).apply {
                setImageDrawable(logo)
                scaleType = ImageView.ScaleType.FIT_CENTER
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, radius)
                    }
                }
                clipToOutline = true
            }
            column.addView(image, LinearLayout.LayoutParams(dp(cfg.iconSizeDp), dp(cfg.iconSizeDp)))
        }

        if (cfg.loaderStyle != "none") {
            val isBar = cfg.loaderStyle == "bar"
            val w = if (isBar) dp(cfg.loaderSizeDp * 3) else dp(cfg.loaderSizeDp)
            val h = if (isBar) dp(cfg.thicknessDp) else dp(cfg.loaderSizeDp)
            val loader = LoaderView(context, isBar, cfg.loaderColor, dp(cfg.thicknessDp).toFloat())
            val lp = LinearLayout.LayoutParams(w, maxOf(h, 1))
            lp.topMargin = if (logo != null) dp(cfg.spacingDp) else 0
            column.addView(loader, lp)
        }
    }

    /** Fades out (fadeMs) and removes itself. Safe to call more than once. */
    fun dismiss() {
        if (dismissed) return
        dismissed = true
        if (cfg.fadeMs <= 0L) {
            (parent as? ViewGroup)?.removeView(this)
            return
        }
        animate().alpha(0f).setDuration(cfg.fadeMs).withEndAction {
            visibility = View.GONE
            (parent as? ViewGroup)?.removeView(this)
        }.start()
    }

    private class LoaderView(
        context: Context,
        private val bar: Boolean,
        private val color: Int,
        private val thickness: Float
    ) : View(context) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@LoaderView.color }
        private val rect = RectF()
        private var t = 0f
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (bar) 1300L else 1000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            animator.start()
        }

        override fun onDetachedFromWindow() {
            animator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (bar) {
                val r = h / 2f
                paint.alpha = 50
                rect.set(0f, 0f, w, h)
                canvas.drawRoundRect(rect, r, r, paint)
                paint.alpha = 255
                val seg = w * 0.35f
                val left = -seg + t * (w + seg)
                rect.set(maxOf(left, 0f), 0f, minOf(left + seg, w), h)
                if (rect.right > rect.left) canvas.drawRoundRect(rect, r, r, paint)
            } else {
                val stroke = maxOf(thickness, 1f)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = stroke
                paint.strokeCap = Paint.Cap.ROUND
                rect.set(stroke / 2f, stroke / 2f, w - stroke / 2f, h - stroke / 2f)
                paint.alpha = 50
                canvas.drawArc(rect, 0f, 360f, false, paint)
                paint.alpha = 255
                canvas.drawArc(rect, t * 360f - 90f, 100f, false, paint)
            }
        }
    }
}
