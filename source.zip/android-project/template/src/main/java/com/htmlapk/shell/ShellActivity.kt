package com.htmlapk.shell

import android.Manifest
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.MimeTypeMap
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException

/**
 * The generated app. Reads assets/config.json and builds the whole UI in code (no XML layouts, no Compose).
 * Bundled files are served from https://appassets.androidplatform.net/assets/www/ so pages get a real https origin
 * (localStorage, IndexedDB and fetch behave like on a normal website).
 */
class ShellActivity : ComponentActivity() {

    private lateinit var cfg: ShellConfig
    private lateinit var saver: MediaSaver
    private lateinit var downloads: DownloadBridge
    private lateinit var nativeApi: NativeApi
    private lateinit var assetLoader: WebViewAssetLoader

    private lateinit var outer: FrameLayout
    private lateinit var frame: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var webView: WebView
    private var swipe: SwipeRefreshLayout? = null
    private var progressBar: ProgressBar? = null
    private var splash: SplashOverlay? = null

    private val handler = Handler(Looper.getMainLooper())
    private val startedAt = System.currentTimeMillis()
    private var pageReady = false
    private var webViewDead = false
    private var lastFailedUrl: String? = null
    private var pendingLaunchUrl: String? = null
    private var nightAtCreate = false

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    // ---- file chooser state -------------------------------------------------------------------------------
    private enum class ChooserMode { FILE, PHOTO, VIDEO }
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var chooserMode = ChooserMode.FILE
    private var cameraUri: Uri? = null

    private val chooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cb = fileCallback
        fileCallback = null
        if (cb == null) return@registerForActivityResult
        val result: Array<Uri>? = when (chooserMode) {
            ChooserMode.FILE -> WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            ChooserMode.VIDEO -> if (res.resultCode == RESULT_OK) res.data?.data?.let { arrayOf(it) } else null
            ChooserMode.PHOTO -> {
                val uri = cameraUri
                if (res.resultCode == RESULT_OK) {
                    if (uri != null) arrayOf(uri) else thumbnailToUri(res.data)
                } else {
                    if (uri != null) try { contentResolver.delete(uri, null, null) } catch (_: Exception) { }
                    null
                }
            }
        }
        cameraUri = null
        cb.onReceiveValue(result)
    }

    // ---- runtime permission queue (one system dialog at a time) ---------------------------------------------
    private class PermRequest(val perms: List<String>, val done: (Boolean) -> Unit)
    private val permQueue = ArrayDeque<PermRequest>()
    private var permBusy = false
    private var permCurrent: PermRequest? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val cur = permCurrent
        permCurrent = null
        permBusy = false
        cur?.done?.invoke(result.isNotEmpty() && result.values.all { it })
        nextPermission()
    }

    // ---------------------------------------------------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        cfg = ShellConfig.load(this)
        setTheme(
            when (cfg.themeMode) {
                "night" -> R.style.Theme_Shell_Dark
                "day" -> R.style.Theme_Shell_Light
                else -> R.style.Theme_Shell
            }
        )
        super.onCreate(savedInstanceState)
        nightAtCreate = isSystemNight()

        saver = MediaSaver(this, cfg.appName)
        downloads = DownloadBridge(this, saver)
        nativeApi = NativeApi(this, cfg, saver)

        applyWindowSettings()
        buildUi(savedInstanceState == null)
        configureWebView()
        installBridges()
        registerBackHandler()
        requestLaunchPermissions()

        pendingLaunchUrl = launchUrlFrom(intent)
        val restored = savedInstanceState != null && webView.restoreState(savedInstanceState) != null
        if (!restored) webView.loadUrl(cfg.resolveStartUrl())
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launchUrlFrom(intent)?.let {
            pendingLaunchUrl = it
            dispatchLaunchUrl()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (!webViewDead) webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        if (!webViewDead) webView.onResume()
    }

    override fun onPause() {
        if (!webViewDead) webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        if (!webViewDead) {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (cfg.themeMode == "auto" && isSystemNight() != nightAtCreate) {
            recreate() // switch between the light and dark activity theme
        }
    }

    private fun isSystemNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    // ---------------------------------------------------------------------------------------------------------
    // Window: orientation, bars, cutout, keep-screen-on
    // ---------------------------------------------------------------------------------------------------------

    private fun applyWindowSettings() {
        requestedOrientation = when (cfg.orientation) {
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            "auto" -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        if (cfg.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Always edge-to-edge: the shell draws the bar colour itself (works the same on Android 5 to 16, including
        // Android 15+, where window.statusBarColor is ignored).
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION")
        run {
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
        }
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= 28) {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode = when {
                !cfg.cutout -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                Build.VERSION.SDK_INT >= 30 -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = attrs
        }
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        val lightBars = ColorUtils.calculateLuminance(cfg.barColor) > 0.5
        controller.isAppearanceLightStatusBars = lightBars
        controller.isAppearanceLightNavigationBars = lightBars
        if (!cfg.statusBarVisible) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.statusBars())
        }
    }

    // ---------------------------------------------------------------------------------------------------------
    // View hierarchy
    // ---------------------------------------------------------------------------------------------------------

    private fun buildUi(showSplash: Boolean) {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        outer = FrameLayout(this)
        frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cfg.barColor)
        }
        outer.addView(frame, FrameLayout.LayoutParams(match, match))

        if (cfg.actionBarVisible) {
            val onBar = if (ColorUtils.calculateLuminance(cfg.barColor) > 0.5) Color.BLACK else Color.WHITE
            val title = TextView(this).apply {
                text = cfg.appName
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(onBar)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                setBackgroundColor(cfg.barColor)
                maxLines = 1
            }
            frame.addView(title, LinearLayout.LayoutParams(match, dp(56)))
        }

        content = FrameLayout(this).apply { setBackgroundColor(cfg.loadingBackground) }
        frame.addView(content, LinearLayout.LayoutParams(match, 0, 1f))

        webView = WebView(this).apply { setBackgroundColor(cfg.loadingBackground) }
        if (cfg.navigation.pullToRefresh) {
            swipe = SwipeRefreshLayout(this).apply {
                addView(webView, ViewGroup.LayoutParams(match, match))
                setOnRefreshListener { webView.reload() }
            }
            content.addView(swipe, FrameLayout.LayoutParams(match, match))
        } else {
            content.addView(webView, FrameLayout.LayoutParams(match, match))
        }

        if (cfg.navigation.loadingIndicator) {
            progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                visibility = View.GONE
                progressTintList = ColorStateList.valueOf(accentColor())
                progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
            }
            content.addView(progressBar, FrameLayout.LayoutParams(match, dp(3), Gravity.TOP))
        }

        if (cfg.splash.enabled && showSplash) {
            val s = SplashOverlay(this, cfg.splash, loadSplashLogo())
            splash = s
            outer.addView(s, FrameLayout.LayoutParams(match, match))
            handler.postDelayed({ s.dismiss() }, cfg.splash.durationMs + 12_000L) // fail-safe
        }

        ViewCompat.setOnApplyWindowInsetsListener(outer) { _, insets ->
            var types = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            if (!cfg.cutout) types = types or WindowInsetsCompat.Type.displayCutout()
            val i = insets.getInsets(types)
            frame.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(outer)
    }

    private fun accentColor(): Int {
        val bar = cfg.barColor
        val bg = cfg.loadingBackground
        return if (kotlin.math.abs(ColorUtils.calculateLuminance(bar) - ColorUtils.calculateLuminance(bg)) > 0.3) bar
        else if (ColorUtils.calculateLuminance(bg) > 0.5) 0xFF2196F3.toInt() else 0xFF38BDF8.toInt()
    }

    private fun loadSplashLogo(): Drawable? {
        if (cfg.splash.imageAsset.isNotBlank()) {
            try {
                assets.open(cfg.splash.imageAsset).use { input ->
                    val bmp = android.graphics.BitmapFactory.decodeStream(input)
                    if (bmp != null) return BitmapDrawable(resources, bmp)
                }
            } catch (_: Exception) { }
        }
        return try { applicationInfo.loadIcon(packageManager) } catch (_: Exception) { null }
    }

    // ---------------------------------------------------------------------------------------------------------
    // WebView configuration
    // ---------------------------------------------------------------------------------------------------------

    @Suppress("DEPRECATION", "SetJavaScriptEnabled")
    private fun configureWebView() {
        val w = cfg.web
        val s = webView.settings
        s.javaScriptEnabled = w.javaScript
        s.domStorageEnabled = w.domStorage
        s.databaseEnabled = true
        s.allowFileAccess = w.fileAccess
        s.allowContentAccess = w.contentAccess
        s.allowUniversalAccessFromFileURLs = w.universalFileAccess
        s.allowFileAccessFromFileURLs = w.fileAccessFromFileUrls
        s.builtInZoomControls = w.builtInZoom
        s.displayZoomControls = false
        s.setSupportZoom(w.builtInZoom)
        s.useWideViewPort = w.wideViewport
        s.loadWithOverviewMode = w.overviewMode
        s.setGeolocationEnabled(w.geolocation)
        s.mediaPlaybackRequiresUserGesture = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.cacheMode = when (w.cacheMode) {
            "no_cache" -> WebSettings.LOAD_NO_CACHE
            "cache_else_network" -> WebSettings.LOAD_CACHE_ELSE_NETWORK
            "cache_only" -> WebSettings.LOAD_CACHE_ONLY
            else -> WebSettings.LOAD_DEFAULT
        }
        s.mixedContentMode = when (w.mixedContent) {
            "never" -> WebSettings.MIXED_CONTENT_NEVER_ALLOW
            "always" -> WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            else -> WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        if (cfg.desktopMode) {
            s.userAgentString = desktopUserAgent(s.userAgentString)
            s.useWideViewPort = true
            s.loadWithOverviewMode = true
        }
        applyDarkMode(s)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(ShellConfig.ASSET_HOST)
            .addPathHandler("/assets/", WwwHandler())
            .build()

        webView.webViewClient = ShellClient()
        webView.webChromeClient = ShellChromeClient()
        webView.setDownloadListener { url, userAgent, contentDisposition, mime, _ ->
            handleDownload(url, userAgent, contentDisposition, mime)
        }
    }

    private fun desktopUserAgent(ua: String): String =
        ua.replace(Regex("\\(Linux; Android [^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "")

    @Suppress("DEPRECATION")
    private fun applyDarkMode(s: WebSettings) {
        val night = when (cfg.themeMode) {
            "night" -> true
            "day" -> false
            else -> isSystemNight()
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            // Algorithmic darkening only applies when the activity theme is dark (Night, or Automatic at night).
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, cfg.themeMode != "day")
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(
                s,
                if (night) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
            )
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                WebSettingsCompat.setForceDarkStrategy(s, WebSettingsCompat.DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING)
            }
        }
    }

    // ---------------------------------------------------------------------------------------------------------
    // Origins and the JavaScript bridge
    // ---------------------------------------------------------------------------------------------------------

    private fun originOf(url: String): String? {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase() ?: return null
        val host = uri.host ?: return null
        if (scheme != "http" && scheme != "https") return null
        return if (uri.port != -1) "$scheme://$host:${uri.port}" else "$scheme://$host"
    }

    /** The one origin that is "ours": the asset host for bundled content, or the start URL's origin. */
    private val ownOrigin: String by lazy {
        if (cfg.isRemote) originOf(cfg.startUrl) ?: ShellConfig.ASSET_ORIGIN else ShellConfig.ASSET_ORIGIN
    }

    private fun isTrustedOrigin(origin: String): Boolean =
        !cfg.navigation.apiOnlyOwnPages || origin.trimEnd('/') == ownOrigin

    /** Used for navigation: keeps the app's own pages (and, for URL apps, the same site) inside the WebView. */
    private fun isOwnSite(uri: Uri): Boolean {
        val host = uri.host?.lowercase() ?: return false
        if (host == ShellConfig.ASSET_HOST) return true
        if (!cfg.isRemote) return false
        val startHost = Uri.parse(cfg.startUrl).host?.lowercase() ?: return false
        val base = startHost.split('.').takeLast(2).joinToString(".")
        return host == startHost || host == base || host.endsWith(".$base")
    }

    private fun installBridges() {
        // Token-gated: only usable by the one-off script the shell injects for a blob download.
        webView.addJavascriptInterface(downloads, DownloadBridge.JS_NAME)

        val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (docStart) {
            WebViewCompat.addDocumentStartJavaScript(webView, DownloadBridge.NAME_HOOK_SCRIPT, setOf("*"))
        }

        if (!cfg.navigation.apiOnlyOwnPages) {
            webView.addJavascriptInterface(nativeApi, "Android")
            return
        }
        if (docStart && WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            val rules = setOf(ownOrigin)
            WebViewCompat.addWebMessageListener(webView, "__androidBridge", rules) { _, message: WebMessageCompat, _, isMainFrame, _ ->
                if (isMainFrame) nativeApi.handleMessage(message.data)
            }
            WebViewCompat.addDocumentStartJavaScript(webView, nativeApi.shimScript(), rules)
        }
        // Old WebView without these features: window.Android is simply not exposed (safe default).
    }

    // ---------------------------------------------------------------------------------------------------------
    // Asset serving
    // ---------------------------------------------------------------------------------------------------------

    private inner class WwwHandler : WebViewAssetLoader.PathHandler {
        override fun handle(path: String): WebResourceResponse? {
            var p = path.trimStart('/')
            if (p.isEmpty() || p.endsWith("/")) p += "index.html"
            if (p.contains("..") || !p.startsWith("www/")) return notFound()
            val stream = try {
                assets.open(p, android.content.res.AssetManager.ACCESS_STREAMING)
            } catch (e: IOException) {
                val last = p.substringAfterLast('/')
                if (last.contains('.')) return notFound()
                try { assets.open("${p.trimEnd('/')}/index.html", android.content.res.AssetManager.ACCESS_STREAMING) } catch (e2: IOException) { return notFound() }
            }
            val mime = mimeFor(p)
            val textual = mime.startsWith("text/") || mime == "application/json" || mime == "image/svg+xml" || mime == "text/javascript"
            return WebResourceResponse(mime, if (textual) "utf-8" else null, stream)
        }

        private fun notFound() = WebResourceResponse(
            "text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream("Not found".toByteArray())
        )
    }

    private fun mimeFor(path: String): String = when (val ext = path.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "js", "mjs" -> "text/javascript"
        "css" -> "text/css"
        "json", "map", "webmanifest" -> "application/json"
        "svg" -> "image/svg+xml"
        "wasm" -> "application/wasm"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "txt" -> "text/plain"
        "xml" -> "text/xml"
        "avif" -> "image/avif"
        "webp" -> "image/webp"
        "ico" -> "image/x-icon"
        "mp3" -> "audio/mpeg"
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    // ---------------------------------------------------------------------------------------------------------
    // WebViewClient
    // ---------------------------------------------------------------------------------------------------------

    private inner class ShellClient : WebViewClient() {

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
            assetLoader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            if (!request.isForMainFrame) return false // never hijack iframes (ads, embeds)
            return handleExternalUrl(request.url.toString())
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            progressBar?.apply { progress = 0; visibility = View.VISIBLE }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            swipe?.isRefreshing = false
            progressBar?.visibility = View.GONE
            if (url != null && url != "about:blank") {
                view.evaluateJavascript(DownloadBridge.NAME_HOOK_SCRIPT, null)
                pageReady = true
                scheduleSplashDismiss()
                dispatchLaunchUrl()
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) {
                val code = if (Build.VERSION.SDK_INT >= 23) error.errorCode else ERROR_UNKNOWN
                val desc = if (Build.VERSION.SDK_INT >= 23) error.description?.toString() ?: "" else ""
                showLoadError(request.url.toString(), code, desc)
            }
        }

        @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
        override fun onReceivedError(view: WebView, errorCode: Int, description: String?, failingUrl: String?) {
            if (Build.VERSION.SDK_INT < 23 && failingUrl != null) showLoadError(failingUrl, errorCode, description ?: "")
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            if (view === webView && !webViewDead) {
                webViewDead = true
                (view.parent as? ViewGroup)?.removeView(view)
                view.destroy()
                recreate() // fresh WebView; the start page is loaded again
            }
            return true
        }
    }

    private fun handleExternalUrl(url: String): Boolean {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase() ?: return false
        return when (scheme) {
            "http", "https" -> {
                if (isOwnSite(uri)) false else { openExternal(uri); true }
            }
            "about", "blob", "data", "javascript", "file", "content" -> false
            "mailto" -> { startExternal(Intent(Intent.ACTION_SENDTO, uri)); true }
            "intent" -> { openIntentUrl(url); true }
            else -> { startExternal(Intent(Intent.ACTION_VIEW, uri)); true } // tel:, sms:, geo:, market:, ...
        }
    }

    private fun openExternal(uri: Uri) = startExternal(Intent(Intent.ACTION_VIEW, uri))

    private fun startExternal(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show()
        false
    } catch (e: Exception) {
        false
    }

    private fun openIntentUrl(url: String) {
        try {
            val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.component = null
            intent.selector = null
            if (!startExternal(intent)) {
                intent.getStringExtra("browser_fallback_url")?.let { fb ->
                    if (fb.startsWith("http")) openExternal(Uri.parse(fb))
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open this link", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------------------------------------------

    private fun isConnectivityError(code: Int) = code == WebViewClient.ERROR_HOST_LOOKUP ||
        code == WebViewClient.ERROR_CONNECT || code == WebViewClient.ERROR_TIMEOUT || code == WebViewClient.ERROR_IO

    private fun showLoadError(url: String, code: Int, description: String) {
        pageReady = true
        scheduleSplashDismiss()
        swipe?.isRefreshing = false
        progressBar?.visibility = View.GONE
        lastFailedUrl = url
        if (cfg.isRemote && cfg.navigation.noInternetDialog && isConnectivityError(code)) {
            AlertDialog.Builder(this)
                .setTitle(R.string.no_internet_title)
                .setMessage(R.string.no_internet_message)
                .setCancelable(false)
                .setPositiveButton(R.string.retry) { _, _ -> webView.loadUrl(url) }
                .setNegativeButton(R.string.close) { _, _ -> finish() }
                .show()
        }
        val dark = ColorUtils.calculateLuminance(cfg.loadingBackground) < 0.5
        val fg = if (dark) "#E5E7EB" else "#111827"
        val bg = String.format("#%06X", 0xFFFFFF and cfg.loadingBackground)
        val html = """
            <html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;background:$bg;color:$fg;font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center">
            <div style="padding:24px"><h2 style="margin:0 0 8px">Page could not be loaded</h2>
            <p style="opacity:.7;margin:0 0 20px">${description.replace("<", "&lt;")}</p>
            <button onclick="location.href=${JSONObject.quote(url)}" style="font-size:16px;padding:12px 28px;border:0;border-radius:24px;background:#38BDF8;color:#04202e">Try again</button></div>
            </body></html>
        """.trimIndent()
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    // ---------------------------------------------------------------------------------------------------------
    // Splash
    // ---------------------------------------------------------------------------------------------------------

    private fun scheduleSplashDismiss() {
        val s = splash ?: return
        val remaining = cfg.splash.durationMs - (System.currentTimeMillis() - startedAt)
        handler.postDelayed({ s.dismiss(); if (splash === s) splash = null }, maxOf(remaining, 0L))
    }

    // ---------------------------------------------------------------------------------------------------------
    // Custom scheme (myapp://...) launch URL
    // ---------------------------------------------------------------------------------------------------------

    private fun launchUrlFrom(i: Intent?): String? {
        val data = i?.data ?: return null
        val scheme = data.scheme?.lowercase() ?: return null
        return if (cfg.customScheme.isNotBlank() && scheme == cfg.customScheme.lowercase()) data.toString() else null
    }

    private fun dispatchLaunchUrl() {
        val url = pendingLaunchUrl ?: return
        val current = webView.url ?: return
        val origin = originOf(current) ?: return
        if (origin != ownOrigin) return
        pendingLaunchUrl = null
        webView.evaluateJavascript(
            "window.__launchUrl=${JSONObject.quote(url)};window.dispatchEvent(new CustomEvent('androidurl',{detail:window.__launchUrl}));",
            null
        )
    }

    // ---------------------------------------------------------------------------------------------------------
    // Back button
    // ---------------------------------------------------------------------------------------------------------

    private fun registerBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    cfg.navigation.backHistory && webView.canGoBack() -> webView.goBack()
                    cfg.navigation.exitConfirm -> AlertDialog.Builder(this@ShellActivity)
                        .setTitle(R.string.exit_title)
                        .setMessage(R.string.exit_message)
                        .setPositiveButton(R.string.exit_yes) { _, _ -> finish() }
                        .setNegativeButton(R.string.exit_no, null)
                        .show()
                    else -> finish()
                }
            }
        })
    }

    // ---------------------------------------------------------------------------------------------------------
    // Downloads (blob:, data:, bundled assets and http/https)
    // ---------------------------------------------------------------------------------------------------------

    private fun fileNameFromDisposition(cd: String?): String? {
        if (cd.isNullOrBlank()) return null
        val m = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd) ?: return null
        return Uri.decode(m.groupValues[1]).trim().ifBlank { null }
    }

    private fun handleDownload(url: String, userAgent: String?, contentDisposition: String?, mime: String?) {
        val named = fileNameFromDisposition(contentDisposition)
        when {
            url.startsWith("blob:") -> {
                val token = downloads.newToken()
                val fallback = named ?: "download_${System.currentTimeMillis()}"
                webView.evaluateJavascript(DownloadBridge.blobScript(url, token, fallback, mime ?: ""), null)
                Toast.makeText(this, "Saving…", Toast.LENGTH_SHORT).show()
            }
            url.startsWith("data:") -> background("Save failed") {
                val where = saver.saveDataUrl(url, named)
                toast("Saved to $where")
            }
            Uri.parse(url).host == ShellConfig.ASSET_HOST -> background("Save failed") {
                val path = Uri.parse(url).path.orEmpty().removePrefix("/assets/").trimStart('/')
                if (!path.startsWith("www/") || path.contains("..")) throw IOException("Not allowed")
                val name = named ?: path.substringAfterLast('/')
                val where = saver.save(name, mime ?: mimeFor(path)) { out -> assets.open(path).use { it.copyTo(out) } }
                toast("Saved to $where")
            }
            else -> try {
                val name = named ?: URLUtil.guessFileName(url, contentDisposition, mime)
                val req = DownloadManager.Request(Uri.parse(url)).apply {
                    if (!mime.isNullOrBlank()) setMimeType(mime)
                    CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                    if (!userAgent.isNullOrBlank()) addRequestHeader("User-Agent", userAgent)
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setTitle(name)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                }
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading $name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternal(Uri.parse(url)) // e.g. no storage permission on Android 9 and below
            }
        }
    }

    private fun background(errorPrefix: String, block: () -> Unit) {
        Thread {
            try {
                block()
            } catch (e: Exception) {
                toast("$errorPrefix: ${e.message}")
            }
        }.start()
    }

    private fun toast(text: String) = runOnUiThread { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }

    // ---------------------------------------------------------------------------------------------------------
    // Permissions
    // ---------------------------------------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun declaredPermissions(): Set<String> = try {
        packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toSet() ?: emptySet()
    } catch (e: Exception) {
        emptySet()
    }

    private val declared: Set<String> by lazy { declaredPermissions() }

    private fun isGranted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /** Requests [perms] (only those declared in the manifest). Calls [done] with true if all declared ones are granted. */
    private fun withPermissions(perms: List<String>, done: (Boolean) -> Unit) {
        val usable = perms.filter { it in declared }
        if (usable.size != perms.size) { done(false); return }
        val missing = usable.filter { !isGranted(it) }
        if (missing.isEmpty()) { done(true); return }
        permQueue.addLast(PermRequest(missing, done))
        nextPermission()
    }

    private fun nextPermission() {
        if (permBusy) return
        val next = permQueue.removeFirstOrNull() ?: return
        permBusy = true
        permCurrent = next
        permLauncher.launch(next.perms.toTypedArray())
    }

    private fun requestLaunchPermissions() {
        val prefs = getSharedPreferences("shell", MODE_PRIVATE)
        if (prefs.getBoolean("asked", false)) return
        prefs.edit().putBoolean("asked", true).apply()
        val candidates = buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.POST_NOTIFICATIONS)
                add(Manifest.permission.READ_MEDIA_IMAGES)
                add(Manifest.permission.READ_MEDIA_VIDEO)
                add(Manifest.permission.READ_MEDIA_AUDIO)
            }
            if (Build.VERSION.SDK_INT >= 29) add(Manifest.permission.ACTIVITY_RECOGNITION)
            add(Manifest.permission.READ_PHONE_STATE)
            add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= 28) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val needed = candidates.filter { it in declared && !isGranted(it) }
        if (needed.isNotEmpty()) {
            permQueue.addLast(PermRequest(needed) { })
            nextPermission()
        }
    }

    // ---------------------------------------------------------------------------------------------------------
    // WebChromeClient: progress, file chooser, camera/mic, geolocation, JS dialogs, fullscreen video
    // ---------------------------------------------------------------------------------------------------------

    private inner class ShellChromeClient : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progressBar?.progress = newProgress
        }

        override fun onShowFileChooser(
            webView: WebView,
            filePathCallback: ValueCallback<Array<Uri>>,
            params: FileChooserParams
        ): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = filePathCallback
            // accept may hold MIME types ("image/*") or extensions (".png"); the chooser intent needs MIME types.
            val accept = params.acceptTypes.flatMap { it.split(',') }.map { it.trim() }.filter { it.isNotEmpty() }
                .mapNotNull { t -> if (t.contains('/')) t else MimeTypeMap.getSingleton().getMimeTypeFromExtension(t.removePrefix(".").lowercase()) }
                .distinct()
            val allImages = accept.isNotEmpty() && accept.all { it.startsWith("image") }
            val allVideo = accept.isNotEmpty() && accept.all { it.startsWith("video") }
            val capture = params.isCaptureEnabled

            when {
                capture && allVideo -> launchCamera(video = true)
                capture && (allImages || accept.isEmpty()) -> launchCamera(video = false)
                else -> {
                    chooserMode = ChooserMode.FILE
                    try {
                        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = if (accept.size == 1) accept[0] else "*/*"
                            if (accept.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, accept.toTypedArray())
                            if (params.mode == FileChooserParams.MODE_OPEN_MULTIPLE) putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        }
                        chooserLauncher.launch(Intent.createChooser(intent, getString(R.string.choose_file)))
                    } catch (e: Exception) {
                        cancelChooser()
                        return false
                    }
                }
            }
            return true
        }

        override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
                val origin = request.origin.toString()
                if (!isTrustedOrigin(origin)) { request.deny(); return@runOnUiThread }
                val resources = mutableListOf<String>()
                val needed = mutableListOf<String>()
                for (r in request.resources) when (r) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> { resources += r; needed += Manifest.permission.CAMERA }
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> { resources += r; needed += Manifest.permission.RECORD_AUDIO }
                }
                if (resources.isEmpty()) { request.deny(); return@runOnUiThread }
                withPermissions(needed) { ok ->
                    if (ok) request.grant(resources.toTypedArray()) else request.deny()
                }
            }
        }

        override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
            if (!cfg.web.geolocation || !isTrustedOrigin(origin)) { callback.invoke(origin, false, false); return }
            val fine = Manifest.permission.ACCESS_FINE_LOCATION
            val coarse = Manifest.permission.ACCESS_COARSE_LOCATION
            val perms = when {
                fine in declared && coarse in declared -> listOf(fine, coarse)
                fine in declared -> listOf(fine)
                coarse in declared -> listOf(coarse)
                else -> { callback.invoke(origin, false, false); return }
            }
            if (perms.any { isGranted(it) }) { callback.invoke(origin, true, false); return }
            withPermissions(perms) { callback.invoke(origin, perms.any { isGranted(it) }, false) }
        }

        override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
            AlertDialog.Builder(this@ShellActivity).setMessage(message)
                .setPositiveButton(R.string.ok) { _, _ -> result.confirm() }
                .setOnCancelListener { result.cancel() }.show()
            return true
        }

        override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
            AlertDialog.Builder(this@ShellActivity).setMessage(message)
                .setPositiveButton(R.string.ok) { _, _ -> result.confirm() }
                .setNegativeButton(R.string.cancel) { _, _ -> result.cancel() }
                .setOnCancelListener { result.cancel() }.show()
            return true
        }

        override fun onJsPrompt(view: WebView, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
            val input = EditText(this@ShellActivity).apply { setText(defaultValue ?: "") }
            AlertDialog.Builder(this@ShellActivity).setMessage(message).setView(input)
                .setPositiveButton(R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                .setNegativeButton(R.string.cancel) { _, _ -> result.cancel() }
                .setOnCancelListener { result.cancel() }.show()
            return true
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) { callback.onCustomViewHidden(); return }
            customView = view
            customViewCallback = callback
            frame.visibility = View.GONE
            outer.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        }

        override fun onHideCustomView() = hideCustomView()
    }

    private fun hideCustomView() {
        val v = customView ?: return
        outer.removeView(v)
        customView = null
        frame.visibility = View.VISIBLE
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.show(WindowInsetsCompat.Type.navigationBars())
        if (cfg.statusBarVisible) controller.show(WindowInsetsCompat.Type.statusBars())
    }

    private fun cancelChooser() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
    }

    private fun launchCamera(video: Boolean) {
        val proceed = {
            try {
                if (video) {
                    chooserMode = ChooserMode.VIDEO
                    chooserLauncher.launch(Intent(MediaStore.ACTION_VIDEO_CAPTURE))
                } else {
                    chooserMode = ChooserMode.PHOTO
                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    cameraUri = null
                    if (Build.VERSION.SDK_INT >= 29) {
                        val values = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + cfg.appName)
                        }
                        cameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        cameraUri?.let { intent.putExtra(MediaStore.EXTRA_OUTPUT, it) }
                    }
                    chooserLauncher.launch(intent)
                }
            } catch (e: Exception) {
                cancelChooser()
            }
        }
        // The camera app needs our CAMERA permission only if the manifest declares it.
        if (Manifest.permission.CAMERA in declared && !isGranted(Manifest.permission.CAMERA)) {
            withPermissions(listOf(Manifest.permission.CAMERA)) { ok -> if (ok) proceed() else cancelChooser() }
        } else {
            proceed()
        }
    }

    /** Android 9 and below: the camera returns only a small thumbnail; save it to cache and hand it to the page. */
    private fun thumbnailToUri(data: Intent?): Array<Uri>? {
        @Suppress("DEPRECATION")
        val bmp = data?.extras?.get("data") as? Bitmap ?: return null
        return try {
            val f = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            arrayOf(Uri.fromFile(f))
        } catch (e: Exception) {
            null
        }
    }
}
