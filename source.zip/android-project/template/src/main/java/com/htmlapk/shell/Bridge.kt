package com.htmlapk.shell

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Saves files to public storage through MediaStore (Android 10+, no storage permission needed).
 * Images go to Pictures/<App>, video to Movies/<App>, audio to Music/<App>, everything else to Download/.
 * On Android 9 and below it writes to the public directory if WRITE_EXTERNAL_STORAGE was declared and granted,
 * otherwise to the app-specific external folder.
 */
class MediaSaver(private val activity: Activity, private val appName: String) {

    fun saveBytes(rawName: String, mime: String, bytes: ByteArray): String =
        save(rawName, mime) { it.write(bytes) }

    /** @return a human readable location such as "Pictures/MyApp/edited.png". */
    fun save(rawName: String, rawMime: String, writer: (OutputStream) -> Unit): String {
        val name0 = sanitizeName(rawName)
        val mime = when {
            rawMime.isNotBlank() && rawMime != "application/octet-stream" -> rawMime.substringBefore(';').trim()
            else -> mimeFromName(name0) ?: "application/octet-stream"
        }
        val name = ensureExtension(name0, mime)
        val folderName = sanitizeName(appName).ifBlank { "App" }

        val baseDir: String
        val collection: Uri?
        val relative: String
        when {
            mime.startsWith("image/") -> {
                baseDir = Environment.DIRECTORY_PICTURES
                collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else null
                relative = "$baseDir/$folderName"
            }
            mime.startsWith("video/") -> {
                baseDir = Environment.DIRECTORY_MOVIES
                collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else null
                relative = "$baseDir/$folderName"
            }
            mime.startsWith("audio/") -> {
                baseDir = Environment.DIRECTORY_MUSIC
                collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else null
                relative = "$baseDir/$folderName"
            }
            else -> {
                baseDir = Environment.DIRECTORY_DOWNLOADS
                collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Downloads.EXTERNAL_CONTENT_URI else null
                relative = baseDir
            }
        }

        if (Build.VERSION.SDK_INT >= 29 && collection != null) {
            val resolver = activity.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values) ?: throw IOException("MediaStore insert failed")
            try {
                val out = resolver.openOutputStream(uri) ?: throw IOException("Cannot open output stream")
                out.use { writer(it) }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                try { resolver.delete(uri, null, null) } catch (_: Exception) { }
                throw e
            }
            return "$relative/$name"
        }

        @Suppress("DEPRECATION")
        val canWritePublic = activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        val dir: File = if (canWritePublic) {
            @Suppress("DEPRECATION")
            File(Environment.getExternalStoragePublicDirectory(baseDir), if (baseDir == Environment.DIRECTORY_DOWNLOADS) "" else folderName)
        } else {
            activity.getExternalFilesDir(baseDir) ?: activity.filesDir
        }
        dir.mkdirs()
        var target = File(dir, name)
        var n = 1
        while (target.exists()) {
            target = File(dir, name.substringBeforeLast('.', name) + " ($n)" + (if (name.contains('.')) "." + name.substringAfterLast('.') else ""))
            n++
        }
        FileOutputStream(target).use { writer(it) }
        MediaScannerConnection.scanFile(activity, arrayOf(target.absolutePath), arrayOf(mime), null)
        return target.absolutePath
    }

    /** Decodes a data: URL and saves it. */
    fun saveDataUrl(url: String, suggestedName: String?): String {
        val comma = url.indexOf(',')
        if (!url.startsWith("data:") || comma < 0) throw IOException("Invalid data URL")
        val meta = url.substring(5, comma)
        val payload = url.substring(comma + 1)
        val mime = meta.substringBefore(';').ifBlank { "text/plain" }
        val bytes = if (meta.endsWith(";base64")) Base64.decode(payload, Base64.DEFAULT) else Uri.decode(payload).toByteArray()
        return saveBytes(suggestedName ?: "download_${System.currentTimeMillis()}", mime, bytes)
    }

    companion object {
        fun sanitizeName(name: String): String =
            name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trim('.').take(120)

        fun mimeFromName(name: String): String? {
            val ext = name.substringAfterLast('.', "").lowercase()
            return if (ext.isEmpty()) null else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        }

        fun ensureExtension(name: String, mime: String): String {
            val fallback = name.ifBlank { "download_${System.currentTimeMillis()}" }
            if (fallback.contains('.') && fallback.substringAfterLast('.').length in 1..5) return fallback
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
                ?: if (mime == "image/jpeg") "jpg" else null
            return if (ext != null) "$fallback.$ext" else fallback
        }
    }
}

/**
 * Token-gated receiver for blob:/data: downloads. The page-side script is injected by the shell for ONE download
 * and carries a random one-time token, so arbitrary pages cannot use this interface to write files by themselves.
 */
class DownloadBridge(private val activity: Activity, private val saver: MediaSaver) {

    private class Pending(val file: File, val out: FileOutputStream)

    private val pending = ConcurrentHashMap<String, Pending>()

    fun newToken(): String {
        if (pending.size > 8) pending.keys.firstOrNull()?.let { abort(it) }
        val token = UUID.randomUUID().toString()
        val file = File.createTempFile("dl", ".tmp", activity.cacheDir)
        pending[token] = Pending(file, FileOutputStream(file))
        return token
    }

    @JavascriptInterface
    fun chunk(token: String, base64: String) {
        val p = pending[token] ?: return
        try {
            p.out.write(Base64.decode(base64, Base64.DEFAULT))
        } catch (e: Exception) {
            abort(token)
            toast("Download failed")
        }
    }

    @JavascriptInterface
    fun finish(token: String, name: String, mime: String) {
        val p = pending.remove(token) ?: return
        try {
            p.out.close()
            val where = saver.save(name, mime) { out -> p.file.inputStream().use { it.copyTo(out) } }
            toast("Saved to $where")
        } catch (e: Exception) {
            toast("Save failed: ${e.message}")
        } finally {
            p.file.delete()
        }
    }

    @JavascriptInterface
    fun fail(token: String, message: String) {
        abort(token)
        toast("Download failed: $message")
    }

    private fun abort(token: String) {
        pending.remove(token)?.let {
            try { it.out.close() } catch (_: Exception) { }
            it.file.delete()
        }
    }

    private fun toast(text: String) = activity.runOnUiThread {
        Toast.makeText(activity, text, Toast.LENGTH_LONG).show()
    }

    companion object {
        const val JS_NAME = "__htmlApkDl"

        /** JS that fetches a blob: URL inside the page, base64-encodes it and streams it to [DownloadBridge]. */
        fun blobScript(blobUrl: String, token: String, fallbackName: String, fallbackMime: String): String = """
            (function(){
              var T=${JSONObject.quote(token)},U=${JSONObject.quote(blobUrl)},N=${JSONObject.quote(fallbackName)},M=${JSONObject.quote(fallbackMime)};
              function fail(m){try{$JS_NAME.fail(T,String(m))}catch(e){}}
              try{
                var x=new XMLHttpRequest();x.open('GET',U,true);x.responseType='blob';
                x.onload=function(){
                  var b=x.response,mime=(b&&b.type)||M,r=new FileReader();
                  r.onloadend=function(){
                    try{
                      var s=String(r.result),d=s.substring(s.indexOf(',')+1),step=524288;
                      for(var p=0;p<d.length;p+=step){$JS_NAME.chunk(T,d.substring(p,p+step));}
                      var name=window.__htmlApkDlName||N;window.__htmlApkDlName=null;
                      $JS_NAME.finish(T,name,mime);
                    }catch(e){fail(e)}
                  };
                  r.onerror=function(){fail('read error')};
                  r.readAsDataURL(b);
                };
                x.onerror=function(){fail('blob fetch failed')};
                x.send();
              }catch(e){fail(e)}
            })();
        """.trimIndent()

        /** Remembers the `download="name.png"` attribute of the anchor the user (or script) just clicked. */
        const val NAME_HOOK_SCRIPT = """
            (function(){
              if(window.__htmlApkHook)return;window.__htmlApkHook=1;
              var rec=function(a){try{if(a&&a.hasAttribute&&a.hasAttribute('download')){var n=a.getAttribute('download');if(n)window.__htmlApkDlName=n;}}catch(e){}};
              document.addEventListener('click',function(e){var t=e.target;while(t&&t.tagName!=='A')t=t.parentNode;rec(t)},true);
              var oc=HTMLAnchorElement.prototype.click;
              HTMLAnchorElement.prototype.click=function(){rec(this);return oc.apply(this,arguments)};
            })();
        """
    }
}

/**
 * The `window.Android` API: vibrate(ms), toast(text), share(text), saveFile(base64, filename, mime),
 * openExternal(url), getAppInfo().
 *
 * Two delivery paths with the same behaviour:
 *  - restricted (default): shim script + WebMessageListener, only injected into the app's own origin, main frame only;
 *  - unrestricted: addJavascriptInterface (when "Android API only on your own pages" is turned off).
 */
class NativeApi(
    private val activity: Activity,
    private val cfg: ShellConfig,
    private val saver: MediaSaver
) {

    fun appInfoJson(): String = JSONObject().apply {
        put("appName", cfg.appName)
        put("packageName", activity.packageName)
        put("versionName", cfg.versionName)
        put("versionCode", cfg.versionCode)
        put("sdkInt", Build.VERSION.SDK_INT)
        put("platform", "html-apk-studio")
    }.toString()

    @JavascriptInterface
    fun vibrate(ms: Long) {
        try {
            val duration = ms.coerceIn(1L, 5000L)
            val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                (activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator == null || !vibrator.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(duration)
            }
        } catch (_: Exception) {
            // VIBRATE not declared or no vibrator: ignore.
        }
    }

    @JavascriptInterface
    fun toast(text: String) {
        activity.runOnUiThread { Toast.makeText(activity, text, Toast.LENGTH_SHORT).show() }
    }

    @JavascriptInterface
    fun share(text: String) {
        activity.runOnUiThread {
            try {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                activity.startActivity(Intent.createChooser(send, null))
            } catch (_: Exception) { }
        }
    }

    @JavascriptInterface
    fun saveFile(base64: String, filename: String, mime: String) {
        try {
            val payload = if (base64.startsWith("data:")) base64.substringAfter(',') else base64
            val bytes = Base64.decode(payload, Base64.DEFAULT)
            val where = saver.saveBytes(filename, mime, bytes)
            toast("Saved to $where")
        } catch (e: Exception) {
            toast("Save failed: ${e.message}")
        }
    }

    @JavascriptInterface
    fun openExternal(url: String) {
        activity.runOnUiThread {
            try {
                val uri = Uri.parse(url)
                val scheme = uri.scheme?.lowercase()
                if (scheme != "http" && scheme != "https" && scheme != "mailto" && scheme != "tel" && scheme != "geo" && scheme != "sms") return@runOnUiThread
                activity.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: ActivityNotFoundException) {
            } catch (_: Exception) { }
        }
    }

    @JavascriptInterface
    fun getAppInfo(): String = appInfoJson()

    /** Entry point of the restricted path. [json] looks like {"m":"toast","a":["hello"]}. */
    fun handleMessage(json: String?) {
        if (json == null) return
        try {
            val o = JSONObject(json)
            val a: JSONArray = o.optJSONArray("a") ?: JSONArray()
            when (o.optString("m")) {
                "vibrate" -> vibrate(a.optLong(0, 50L))
                "toast" -> toast(a.optString(0))
                "share" -> share(a.optString(0))
                "saveFile" -> saveFile(a.optString(0), a.optString(1, "download"), a.optString(2, ""))
                "openExternal" -> openExternal(a.optString(0))
            }
        } catch (_: Exception) { }
    }

    /** Defines window.Android for the restricted path. getAppInfo() returns a value baked in at injection time. */
    fun shimScript(): String = """
        (function(){
          if(window.Android)return;
          var INFO=${JSONObject.quote(appInfoJson())};
          function post(m,a){try{__androidBridge.postMessage(JSON.stringify({m:m,a:a}))}catch(e){}}
          window.Android={
            vibrate:function(ms){post('vibrate',[Number(ms)||50])},
            toast:function(t){post('toast',[String(t)])},
            share:function(t){post('share',[String(t)])},
            saveFile:function(b,f,m){post('saveFile',[String(b),String(f||'download'),String(m||'')])},
            openExternal:function(u){post('openExternal',[String(u)])},
            getAppInfo:function(){return INFO}
          };
        })();
    """.trimIndent()
}
