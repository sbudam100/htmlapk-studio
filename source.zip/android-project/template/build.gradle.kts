import org.jetbrains.kotlin.gradle.dsl.JvmTarget

// The :template module is the tiny View-based WebView shell. Its UNSIGNED release APK is copied into the
// builder's assets as template.apk by :app (see app/build.gradle.kts). The builder patches the binary manifest,
// injects config.json + www/**, replaces the launcher PNGs, zip-aligns and signs it on the phone.
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    // Kotlin namespace (class lookup / R class). The manifest uses fully-qualified class names, so the
    // builder can freely change the manifest `package` (the applicationId) without breaking class lookup.
    namespace = "com.htmlapk.shell"
    compileSdk = 36

    defaultConfig {
        // Placeholder id; the builder rewrites it. Intentionally NOT a prefix of the Kotlin namespace.
        applicationId = "com.htmlapk.shell.template"
        minSdk = 21
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            isDebuggable = false
            // Left unsigned on purpose: the builder signs every generated APK itself.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = false
        resValues = false
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    packaging {
        resources {
            excludes += setOf("/META-INF/*.version", "/META-INF/*.kotlin_module", "/DebugProbesKt.bin", "/kotlin/**", "/META-INF/versions/**")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.webkit)
    implementation(libs.androidx.swiperefreshlayout)
}
