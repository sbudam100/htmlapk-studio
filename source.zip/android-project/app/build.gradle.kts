import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

/**
 * Copies the :template module's unsigned release APK into a generated assets directory as `template.apk`.
 * Registered as a generated asset source for every variant, so `./gradlew assembleDebug` builds the template
 * first and bundles it automatically. No manual step is needed.
 */
abstract class CopyTemplateApkTask : DefaultTask() {
    @get:InputDirectory
    @get:PathSensitive(PathSensitivity.RELATIVE)
    abstract val templateApkDir: DirectoryProperty

    @get:OutputDirectory
    abstract val outputDir: DirectoryProperty

    @TaskAction
    fun copyApk() {
        val apk = templateApkDir.get().asFile.walkTopDown()
            .firstOrNull { it.isFile && it.extension == "apk" }
            ?: throw GradleException("Template APK not found in ${templateApkDir.get().asFile}")
        val out = outputDir.get().asFile
        out.deleteRecursively()
        out.mkdirs()
        apk.copyTo(File(out, "template.apk"), overwrite = true)
    }
}

android {
    namespace = "com.htmlapk.studio"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.htmlapk.studio"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Debug-signed so a release build can be installed directly for testing.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    androidResources {
        noCompress += "apk"
    }

    lint {
        abortOnError = false
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/versions/**",
                "/META-INF/DEPENDENCIES",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "/META-INF/INDEX.LIST",
                "/META-INF/*.kotlin_module",
                "/META-INF/*.version",
                "/META-INF/proguard/**"
            )
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

val copyTemplateApk = tasks.register<CopyTemplateApkTask>("copyTemplateApk") {
    dependsOn(":template:assembleRelease")
    templateApkDir.set(project(":template").layout.buildDirectory.dir("outputs/apk/release"))
    outputDir.set(layout.buildDirectory.dir("generated/templateAssets"))
}

androidComponents {
    onVariants { variant ->
        variant.sources.assets?.addGeneratedSourceDirectory(copyTemplateApk, CopyTemplateApkTask::outputDir)
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.documentfile)
    implementation(libs.androidx.webkit)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)

    // APK generation: binary manifest editing, signing, certificate generation.
    implementation(libs.arsclib)
    implementation(libs.apksig)
    implementation(libs.bouncycastle.bcprov)
    implementation(libs.bouncycastle.bcpkix)

    testImplementation(libs.junit)
}
