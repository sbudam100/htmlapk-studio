package com.htmlapk.studio.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyToolsTest {
    @Test
    fun generatesLoadsAndReopensKeystore() {
        val g = KeyTools.generate("htmlapk", "secret123", 30, DistinguishedName(commonName = "Test", organization = "Org", country = "DE"), "Test")
        assertTrue(g.subject.contains("CN=Test"))
        assertTrue(g.validUntil > System.currentTimeMillis() + 25L * 365 * 24 * 3600 * 1000)
        val (ks, type) = KeyTools.open(g.bytes, "secret123")
        assertEquals("PKCS12", type)
        assertTrue(ks.isKeyEntry("htmlapk"))
        val signer = KeyTools.loadSigner(g.bytes, "PKCS12", "htmlapk", "secret123", "secret123")
        assertEquals("RSA", signer.privateKey.algorithm)
        assertEquals(1, signer.certificates.size)
        signer.certificates[0].checkValidity()
    }

    @Test
    fun wrongPasswordIsRejected() {
        val g = KeyTools.generate("a", "secret123", 1, DistinguishedName(), "x")
        val failed = try { KeyTools.open(g.bytes, "nope-nope"); false } catch (e: java.io.IOException) { true }
        assertTrue(failed)
    }
}
