package com.htmlapk.studio.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object Palette {
    val Accent = Color(0xFF38BDF8)
    val OnAccent = Color(0xFF04202E)
    val Background = Color(0xFF0B0B0F)
    val Card = Color(0xFF1C1C21)
    val CardHigh = Color(0xFF26262C)
    val Outline = Color(0xFF3A3A42)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF9CA3AF)
    val Error = Color(0xFFF87171)
    val Success = Color(0xFF4ADE80)
    val Disabled = Color(0xFF3A3A42)
}

private val StudioColors = darkColorScheme(
    primary = Palette.Accent,
    onPrimary = Palette.OnAccent,
    primaryContainer = Color(0xFF0C4A6E),
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = Palette.Accent,
    onSecondary = Palette.OnAccent,
    background = Palette.Background,
    onBackground = Palette.TextPrimary,
    surface = Palette.Card,
    onSurface = Palette.TextPrimary,
    surfaceVariant = Palette.CardHigh,
    onSurfaceVariant = Palette.TextSecondary,
    surfaceContainer = Palette.Card,
    surfaceContainerHigh = Palette.CardHigh,
    surfaceContainerHighest = Palette.CardHigh,
    outline = Palette.Outline,
    outlineVariant = Palette.Outline,
    error = Palette.Error
)

private val StudioShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun StudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = StudioColors, shapes = StudioShapes, content = content)
}
