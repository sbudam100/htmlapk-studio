package com.htmlapk.studio.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.htmlapk.studio.build.Installer
import com.htmlapk.studio.model.BuiltApk
import java.text.DateFormat
import java.util.Date

class ApkActions(
    val install: (BuiltApk) -> Unit,
    val share: (BuiltApk) -> Unit,
    val saveToDownloads: (BuiltApk) -> Unit
)

fun formatSize(bytes: Long): String = when {
    bytes >= 1024L * 1024 -> String.format("%.1f MB", bytes / 1024.0 / 1024.0)
    bytes >= 1024 -> String.format("%d KB", bytes / 1024)
    else -> "$bytes B"
}

fun formatDate(ms: Long): String = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

/**
 * Install / Share / Save-to-Downloads with all the permission round trips:
 *  - Install: if "Install unknown apps" is off, opens that settings page, then continues automatically on return.
 *  - Save: asks for WRITE_EXTERNAL_STORAGE only on Android 9 and below.
 */
@Composable
fun rememberApkActions(vm: AppViewModel): ApkActions {
    val context = LocalContext.current
    var pendingInstall by remember { mutableStateOf<BuiltApk?>(null) }
    var pendingSave by remember { mutableStateOf<BuiltApk?>(null) }

    fun launchInstall(ctx: Context, apk: BuiltApk) {
        try {
            ctx.startActivity(Installer.installIntent(ctx, vm.apkFile(apk)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "No package installer found on this device", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Cannot start installer: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun doSave(ctx: Context, apk: BuiltApk) {
        try {
            val where = Installer.saveToDownloads(ctx, vm.apkFile(apk))
            Toast.makeText(ctx, "Saved to $where", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    val settingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val apk = pendingInstall
        pendingInstall = null
        if (apk != null) {
            if (Installer.canInstall(context)) launchInstall(context, apk)
            else Toast.makeText(context, "Installing is still not allowed for this app", Toast.LENGTH_LONG).show()
        }
    }

    val storagePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val apk = pendingSave
        pendingSave = null
        if (apk != null) {
            if (granted) doSave(context, apk)
            else Toast.makeText(context, "Storage permission denied", Toast.LENGTH_LONG).show()
        }
    }

    return ApkActions(
        install = { apk ->
            if (Installer.canInstall(context)) {
                launchInstall(context, apk)
            } else {
                pendingInstall = apk
                Toast.makeText(context, "Allow \"Install unknown apps\" for this app, then come back", Toast.LENGTH_LONG).show()
                settingsLauncher.launch(Installer.unknownSourcesSettingsIntent(context))
            }
        },
        share = { apk ->
            try {
                context.startActivity(Installer.shareIntent(context, vm.apkFile(apk)))
            } catch (e: Exception) {
                Toast.makeText(context, "Cannot share: ${e.message}", Toast.LENGTH_LONG).show()
            }
        },
        saveToDownloads = { apk ->
            if (Installer.needsLegacyWritePermission(context)) {
                pendingSave = apk
                @Suppress("DEPRECATION")
                storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            } else {
                doSave(context, apk)
            }
        }
    )
}
