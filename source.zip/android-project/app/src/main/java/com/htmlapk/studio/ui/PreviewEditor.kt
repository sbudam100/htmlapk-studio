package com.htmlapk.studio.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color as AColor
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.WrapText
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.htmlapk.studio.model.CacheMode
import com.htmlapk.studio.model.MixedContentMode
import com.htmlapk.studio.model.Project
import com.htmlapk.studio.model.SourceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun ScreenTopBar(title: String, onBack: () -> Unit, actions: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Palette.TextPrimary) }
        Text(title, color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        actions()
    }
}

// ------------------------------------------------------------------------------------------------ Preview

private const val ASSET_HOST = "appassets.androidplatform.net"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewScreen(vm: AppViewModel) {
    val p = vm.draft ?: return
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var chooserCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val chooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        chooserCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        chooserCallback = null
    }

    val startUrl = if (p.sourceType == SourceType.URL) p.websiteUrl
    else "https://$ASSET_HOST/assets/www/" + (if (p.sourceType == SourceType.HTML) "index.html" else p.entryFile)

    BackHandler { vm.screen = Screen.WIZARD }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Preview", onBack = { vm.screen = Screen.WIZARD }) {
            IconButton(onClick = { webViewRef?.reload() }) { Icon(Icons.Filled.Refresh, "Reload", tint = Palette.Accent) }
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                val loader = WebViewAssetLoader.Builder()
                    .setDomain(ASSET_HOST)
                    .addPathHandler("/assets/www/", WebViewAssetLoader.InternalStoragePathHandler(ctx, vm.wwwDir()))
                    .build()
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    applyPreviewSettings(this, p)
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                            loader.shouldInterceptRequest(request.url)
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onShowFileChooser(
                            webView: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
                        ): Boolean {
                            chooserCallback?.onReceiveValue(null)
                            chooserCallback = callback
                            return try {
                                chooser.launch(params.createIntent())
                                true
                            } catch (e: Exception) {
                                chooserCallback = null
                                callback.onReceiveValue(null)
                                false
                            }
                        }
                    }
                    setDownloadListener { _, _, _, _, _ ->
                        vm.toast("Downloads and saving work in the built app, not in this preview.")
                    }
                    webViewRef = this
                    loadUrl(startUrl)
                }
            },
            onRelease = { it.stopLoading(); it.destroy() }
        )
    }
}

@Suppress("DEPRECATION", "SetJavaScriptEnabled")
private fun applyPreviewSettings(webView: WebView, p: Project) {
    val w = p.webView
    val s = webView.settings
    webView.setBackgroundColor(p.loadingBackground)
    s.javaScriptEnabled = w.javaScript
    s.domStorageEnabled = w.domStorage
    s.allowFileAccess = false
    s.allowContentAccess = false
    s.builtInZoomControls = w.builtInZoom
    s.displayZoomControls = false
    s.useWideViewPort = w.wideViewport
    s.loadWithOverviewMode = w.overviewMode
    s.setGeolocationEnabled(w.geolocation)
    s.mediaPlaybackRequiresUserGesture = false
    s.cacheMode = when (w.cacheMode) {
        CacheMode.DEFAULT -> WebSettings.LOAD_DEFAULT
        CacheMode.NO_CACHE -> WebSettings.LOAD_NO_CACHE
        CacheMode.CACHE_ELSE_NETWORK -> WebSettings.LOAD_CACHE_ELSE_NETWORK
        CacheMode.CACHE_ONLY -> WebSettings.LOAD_CACHE_ONLY
    }
    s.mixedContentMode = when (w.mixedContent) {
        MixedContentMode.COMPATIBILITY -> WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        MixedContentMode.NEVER -> WebSettings.MIXED_CONTENT_NEVER_ALLOW
        MixedContentMode.ALWAYS -> WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
    }
    if (p.desktopMode) {
        s.userAgentString = s.userAgentString.replace(Regex("\\(Linux; Android [^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "")
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
    }
}

// ------------------------------------------------------------------------------------------------ HTML editor

/** Simple full-screen monospace editor: Save, line wrap toggle and undo (debounced snapshots). */
@Composable
fun EditorScreen(vm: AppViewModel) {
    val file = remember { vm.editableFile() }
    var loaded by remember { mutableStateOf<String?>(null) }
    var wrap by remember { mutableStateOf(true) }
    var confirmExit by remember { mutableStateOf(false) }
    val editorRef = remember { arrayOfNulls<EditText>(1) }
    val state = remember { EditorState() }

    LaunchedEffect(file) {
        loaded = if (file != null) withContext(Dispatchers.IO) { file.readText(Charsets.UTF_8) } else ""
    }

    fun isDirty(): Boolean = editorRef[0]?.text?.toString()?.let { it != state.saved } ?: false
    fun exit() { vm.screen = Screen.WIZARD }

    BackHandler { if (isDirty()) confirmExit = true else exit() }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Edit HTML", onBack = { if (isDirty()) confirmExit = true else exit() }) {
            IconButton(onClick = { editorRef[0]?.let { state.undo(it) } }) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = Palette.TextPrimary) }
            IconButton(onClick = {
                wrap = !wrap
                editorRef[0]?.setHorizontallyScrolling(!wrap)
            }) { Icon(Icons.AutoMirrored.Filled.WrapText, "Line wrap", tint = if (wrap) Palette.Accent else Palette.TextSecondary) }
            IconButton(onClick = {
                val ed = editorRef[0]
                if (ed != null && file != null) {
                    val text = ed.text.toString()
                    vm.saveEditedFile(file, text)
                    state.saved = text
                }
            }) { Icon(Icons.Filled.Save, "Save", tint = Palette.Accent) }
        }

        val text = loaded
        if (file == null) {
            Text("There is no file to edit.", color = Palette.TextSecondary, modifier = Modifier.padding(20.dp))
        } else if (text == null) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(Modifier.padding(40.dp), color = Palette.Accent)
            }
        } else {
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { ctx ->
                    EditText(ctx).apply {
                        editorRef[0] = this
                        typeface = Typeface.MONOSPACE
                        textSize = 13f
                        setTextColor(AColor.parseColor("#E5E7EB"))
                        setBackgroundColor(AColor.parseColor("#111114"))
                        setPadding(24, 16, 24, 16)
                        gravity = Gravity.TOP or Gravity.START
                        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                        setHorizontallyScrolling(!wrap)
                        isVerticalScrollBarEnabled = true
                        setText(text)
                        state.attach(this, text)
                    }
                },
                onRelease = { state.detach(it) }
            )
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            containerColor = Palette.Card,
            title = { Text("Discard changes?", color = Palette.TextPrimary) },
            text = { Text("You have unsaved changes.", color = Palette.TextSecondary) },
            confirmButton = { TextButton(onClick = { confirmExit = false; exit() }) { Text("Discard", color = Palette.Error) } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Keep editing", color = Palette.TextSecondary) } }
        )
    }
}

/** Undo history: a snapshot is stored when typing pauses for 700 ms (max 15 snapshots to bound memory). */
private class EditorState {
    var saved: String = ""
    private val history = ArrayList<String>()
    private var lastSnapshot = ""
    private var suppress = false
    private val handler = Handler(Looper.getMainLooper())
    private var watcher: TextWatcher? = null
    private var pending: Runnable? = null

    fun attach(editor: EditText, initial: String) {
        saved = initial
        lastSnapshot = initial
        history.clear()
        watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppress) return
                pending?.let { handler.removeCallbacks(it) }
                val r = Runnable { commit(editor) }
                pending = r
                handler.postDelayed(r, 700)
            }
        }
        editor.addTextChangedListener(watcher)
    }

    fun detach(editor: EditText) {
        pending?.let { handler.removeCallbacks(it) }
        watcher?.let { editor.removeTextChangedListener(it) }
    }

    private fun commit(editor: EditText) {
        val now = editor.text.toString()
        if (now != lastSnapshot) {
            history.add(lastSnapshot)
            if (history.size > 15) history.removeAt(0)
            lastSnapshot = now
        }
    }

    fun undo(editor: EditText) {
        pending?.let { handler.removeCallbacks(it) }
        commit(editor)
        if (history.isEmpty()) return
        val previous = history.removeAt(history.size - 1)
        suppress = true
        val cursor = minOf(editor.selectionStart.coerceAtLeast(0), previous.length)
        editor.setText(previous)
        editor.setSelection(cursor)
        suppress = false
        lastSnapshot = previous
    }
}
