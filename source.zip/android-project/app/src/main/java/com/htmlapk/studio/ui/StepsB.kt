package com.htmlapk.studio.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.htmlapk.studio.data.IconProcessor
import com.htmlapk.studio.model.CacheMode
import com.htmlapk.studio.model.LoaderStyle
import com.htmlapk.studio.model.MixedContentMode
import com.htmlapk.studio.model.Project
import com.htmlapk.studio.model.SplashSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------------------------------------ Step 5

@Composable
fun IconStep(vm: AppViewModel, p: Project) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<Bitmap?>(null) }
    var crop by remember { mutableStateOf(true) }

    val preview by produceState<ImageBitmap?>(null, vm.iconVersion, p.hasIcon) {
        value = if (p.hasIcon) withContext(Dispatchers.IO) { IconProcessor.load(vm.projectRepo.iconFile(p.id))?.asImageBitmap() } else null
    }

    fun apply(bmp: Bitmap, cropToSquare: Boolean) {
        vm.saveIcon(if (cropToSquare) IconProcessor.centerCropSquare(bmp) else IconProcessor.letterboxSquare(bmp))
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try { IconProcessor.decode(context, uri, 1024) } catch (e: Throwable) { null }
            }
            if (bmp == null) vm.toast("Could not read that image") else {
                source = bmp
                apply(bmp, crop)
            }
        }
    }

    SectionTitle("App Icon")
    Gap(4)
    Helper("Choose a square image. This will be your app's icon on the phone.")
    Gap(16)
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(160.dp).clip(RoundedCornerShape(36.dp)).background(Palette.CardHigh)
                .border(1.dp, Palette.Outline, RoundedCornerShape(36.dp)),
            contentAlignment = Alignment.Center
        ) {
            val img = preview
            if (img != null) Image(img, "Icon preview", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Filled.Image, null, tint = Palette.TextSecondary, modifier = Modifier.size(56.dp))
        }
    }
    Gap(16)
    ActionButton("Pick from Gallery", Icons.Filled.PhotoLibrary, filled = true) {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    val src = source
    if (src != null && src.width != src.height) {
        Gap(8)
        CheckRow(
            title = "Center-crop to square",
            subtitle = "Off: the whole picture is kept and padded with transparent edges.",
            checked = crop,
            onChange = { v -> crop = v; apply(src, v) }
        )
    }
    if (p.hasIcon) {
        Gap(8)
        ActionButton("Remove icon", Icons.Filled.Image, filled = false) { source = null; vm.saveIcon(null) }
        Gap(8)
        StatusBox(true, listOf("Custom icon selected. It is resized to 48 / 72 / 96 / 144 / 192 px for the APK."))
    } else {
        Gap(12)
        Helper("No icon chosen: the app gets a default placeholder icon.")
    }
}

// ------------------------------------------------------------------------------------------------ Step 6

private val splashBgColors = listOf(
    0xFF0F172A.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF2196F3.toInt(), 0xFF1E293B.toInt(), 0xFF009688.toInt()
)
private val ringColors = listOf(
    0xFF00E5CC.toInt(), 0xFF38BDF8.toInt(), 0xFFFFFFFF.toInt(), 0xFFFB923C.toInt(), 0xFFF472B6.toInt(), 0xFF111827.toInt()
)

@Composable
fun SplashStep(vm: AppViewModel, p: Project) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = p.splash
    fun set(t: (SplashSettings) -> SplashSettings) = vm.update { it.copy(splash = t(it.splash)) }

    val logo by produceState<ImageBitmap?>(null, vm.iconVersion, vm.splashVersion, p.hasIcon, p.hasSplashImage) {
        value = withContext(Dispatchers.IO) {
            val f = when {
                p.hasSplashImage -> vm.projectRepo.splashFile(p.id)
                p.hasIcon -> vm.projectRepo.iconFile(p.id)
                else -> null
            }
            f?.let { IconProcessor.load(it)?.asImageBitmap() }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { try { IconProcessor.decode(context, uri, 512) } catch (e: Throwable) { null } }
            if (bmp == null) vm.toast("Could not read that image") else vm.saveSplashImage(bmp)
        }
    }

    SectionTitle("Splash screen")
    Helper("First screen shown when the app opens")
    Gap(12)
    SwitchRow(
        title = "Enable splash screen",
        subtitle = "Shows your logo and loading animation when the app opens",
        checked = s.enabled,
        onChange = { v -> set { it.copy(enabled = v) } }
    )
    Gap(8)

    if (!s.enabled) {
        StatusBox(false, listOf("Splash screen is disabled. The app will launch directly into main content."))
        return
    }

    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { SplashPreview(s, logo) }
    Gap(16)

    Text2("Background color")
    SwatchRow(splashBgColors, s.backgroundColor, { c -> set { it.copy(backgroundColor = c) } }, allowCustom = true)
    Gap(12)
    Text2("Ring / loader color")
    SwatchRow(ringColors, s.loaderColor, { c -> set { it.copy(loaderColor = c) } }, allowCustom = true)
    Gap(12)
    Text2("Loader style")
    Gap(4)
    SegmentedRow(
        options = LoaderStyle.entries.map { it.label },
        selectedIndex = s.loaderStyle.ordinal,
        onSelect = { i -> set { it.copy(loaderStyle = LoaderStyle.entries[i]) } }
    )
    Gap(8)
    SliderRow("Icon size", s.iconSizeDp, 40..240, { v -> set { it.copy(iconSizeDp = v) } }, format = { "$it dp" })
    SliderRow("Icon corners", s.iconCornerDp, 0..120, { v -> set { it.copy(iconCornerDp = v) } }, format = { "$it dp" })
    SliderRow("Loader size", s.loaderSizeDp, 16..120, { v -> set { it.copy(loaderSizeDp = v) } }, format = { "$it dp" })
    SliderRow("Spacing", s.spacingDp, 0..80, { v -> set { it.copy(spacingDp = v) } }, format = { "$it dp" })
    SliderRow("Display duration", s.durationMs, 0..10000, { v -> set { it.copy(durationMs = v) } }, step = 250, format = { "${it / 1000.0} s" })
    SliderRow("Bar / loader thickness", s.thicknessDp, 1..16, { v -> set { it.copy(thicknessDp = v) } }, format = { "$it dp" })
    SliderRow("Fade transition", s.fadeMs, 0..2000, { v -> set { it.copy(fadeMs = v) } }, step = 50, format = { "$it ms" })
    Gap(8)

    Helper(
        if (p.hasSplashImage) "Using a custom splash image."
        else "Using app icon. App icon is used if no custom image is selected."
    )
    Gap(8)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ActionButton("Pick Custom Image", Icons.Filled.PhotoLibrary, filled = false, modifier = Modifier.weight(1f)) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        if (p.hasSplashImage) {
            ActionButton("Use app icon", Icons.Filled.Image, filled = false, modifier = Modifier.weight(1f)) { vm.saveSplashImage(null) }
        }
    }
}

@Composable
private fun Text2(text: String) {
    androidx.compose.material3.Text(text, color = Palette.TextPrimary, fontSize = androidx.compose.ui.unit.TextUnit(15f, androidx.compose.ui.unit.TextUnitType.Sp))
    Gap(6)
}

/** Phone-shaped live preview, drawn at half scale so dp values map 1:2 to a real phone screen. */
@Composable
fun SplashPreview(s: SplashSettings, logo: ImageBitmap?) {
    val k = 0.5f
    Box(
        Modifier.width(176.dp).height(330.dp)
            .clip(RoundedCornerShape(30.dp))
            .border(4.dp, Palette.Outline, RoundedCornerShape(30.dp))
            .background(Color(s.backgroundColor)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val size = (s.iconSizeDp * k).dp
            Box(
                Modifier.size(size).clip(RoundedCornerShape((s.iconCornerDp * k).dp)).background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                if (logo != null) Image(logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                else Icon(Icons.Filled.Language, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(size * 0.6f))
            }
            if (s.loaderStyle != LoaderStyle.NONE) {
                Spacer(Modifier.height((s.spacingDp * k).dp))
                PreviewLoader(s, k)
            }
        }
    }
}

@Composable
private fun PreviewLoader(s: SplashSettings, k: Float) {
    val t by rememberInfiniteTransition(label = "loader").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    val color = Color(s.loaderColor)
    val thickness = (s.thicknessDp * k).coerceAtLeast(1f)
    if (s.loaderStyle == LoaderStyle.RING) {
        val d = (s.loaderSizeDp * k).dp
        Canvas(Modifier.size(d)) {
            val stroke = Stroke(width = thickness.dp.toPx(), cap = StrokeCap.Round)
            val inset = stroke.width / 2f
            val arcSize = Size(size.width - stroke.width, size.height - stroke.width)
            drawArc(color.copy(alpha = 0.2f), 0f, 360f, false, Offset(inset, inset), arcSize, style = stroke)
            drawArc(color, t * 360f - 90f, 100f, false, Offset(inset, inset), arcSize, style = stroke)
        }
    } else {
        Canvas(Modifier.width((s.loaderSizeDp * 3 * k).dp).height(thickness.dp)) {
            val r = size.height / 2f
            drawRoundRect(color.copy(alpha = 0.2f), size = size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r))
            val seg = size.width * 0.35f
            val left = -seg + t * (size.width + seg)
            val l = left.coerceAtLeast(0f)
            val rr = (left + seg).coerceAtMost(size.width)
            if (rr > l) drawRoundRect(color, Offset(l, 0f), Size(rr - l, size.height), androidx.compose.ui.geometry.CornerRadius(r, r))
        }
    }
}

// ------------------------------------------------------------------------------------------------ Step 7

@Composable
fun WebViewStep(vm: AppViewModel, p: Project) {
    val n = p.navigation
    val w = p.webView
    fun nav(t: (com.htmlapk.studio.model.NavigationSettings) -> com.htmlapk.studio.model.NavigationSettings) =
        vm.update { it.copy(navigation = t(it.navigation)) }
    fun web(t: (com.htmlapk.studio.model.WebViewSettings) -> com.htmlapk.studio.model.WebViewSettings) =
        vm.update { it.copy(webView = t(it.webView)) }

    SectionTitle("WebView")
    Gap(8)
    SubTitle("Navigation & Experience")
    CheckRow("Pull to refresh", n.pullToRefresh, { v -> nav { it.copy(pullToRefresh = v) } }, subtitle = "Swipe down to reload the web page")
    CheckRow("No internet dialog", n.noInternetDialog, { v -> nav { it.copy(noInternetDialog = v) } }, subtitle = "Show an alert to retry when connection is lost")
    CheckRow("Loading indicator", n.loadingIndicator, { v -> nav { it.copy(loadingIndicator = v) } }, subtitle = "Show a progress bar at the top while loading")
    CheckRow("Back button history navigation", n.backHistory, { v -> nav { it.copy(backHistory = v) } })
    CheckRow("Exit confirmation dialog", n.exitConfirm, { v -> nav { it.copy(exitConfirm = v) } })
    CheckRow(
        "Android API only on your own pages", n.apiOnlyOwnPages, { v -> nav { it.copy(apiOnlyOwnPages = v) } },
        subtitle = "Other websites and embedded frames (ads, videos) cannot use files, location, microphone and other device features. Turn off only if you trust every page the app opens."
    )
    Gap(12)
    SubTitle("Advanced WebView Settings")
    SwitchRow("JavaScript Enabled", w.javaScript, { v -> web { it.copy(javaScript = v) } })
    SwitchRow("DOM Storage Enabled", w.domStorage, { v -> web { it.copy(domStorage = v) } })
    SwitchRow("Allow File Access", w.fileAccess, { v -> web { it.copy(fileAccess = v) } })
    SwitchRow("Allow Content Access", w.contentAccess, { v -> web { it.copy(contentAccess = v) } })
    SwitchRow("Universal File Access", w.universalFileAccess, { v -> web { it.copy(universalFileAccess = v) } })
    SwitchRow("File Access From File URLs", w.fileAccessFromFileUrls, { v -> web { it.copy(fileAccessFromFileUrls = v) } })
    SwitchRow("Built-in Zoom Controls", w.builtInZoom, { v -> web { it.copy(builtInZoom = v) } })
    SwitchRow("Use Wide Viewport", w.wideViewport, { v -> web { it.copy(wideViewport = v) } })
    SwitchRow("Load With Overview Mode", w.overviewMode, { v -> web { it.copy(overviewMode = v) } })
    SwitchRow("Geolocation Enabled", w.geolocation, { v -> web { it.copy(geolocation = v) } })
    Gap(12)
    DropdownField(
        label = "Cache Mode",
        options = CacheMode.entries.map { it.label },
        selectedIndex = w.cacheMode.ordinal,
        onSelect = { i -> web { it.copy(cacheMode = CacheMode.entries[i]) } }
    )
    Gap(8)
    DropdownField(
        label = "Mixed Content Mode",
        options = MixedContentMode.entries.map { it.label },
        selectedIndex = w.mixedContent.ordinal,
        onSelect = { i -> web { it.copy(mixedContent = MixedContentMode.entries[i]) } }
    )
}

@Composable
private fun SubTitle(text: String) {
    androidx.compose.material3.Text(
        text, color = Palette.Accent,
        fontSize = androidx.compose.ui.unit.TextUnit(15f, androidx.compose.ui.unit.TextUnitType.Sp),
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    Gap(4)
}
