package com.htmlapk.studio

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.htmlapk.studio.ui.AppViewModel
import com.htmlapk.studio.ui.BuildScreen
import com.htmlapk.studio.ui.BuildUiState
import com.htmlapk.studio.ui.EditorScreen
import com.htmlapk.studio.ui.HomeScreen
import com.htmlapk.studio.ui.KeystoreScreen
import com.htmlapk.studio.ui.Palette
import com.htmlapk.studio.ui.PreviewScreen
import com.htmlapk.studio.ui.Screen
import com.htmlapk.studio.ui.StudioTheme
import com.htmlapk.studio.ui.WizardScreen

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            StudioTheme {
                StudioApp(vm)
            }
        }
    }
}

@Composable
fun StudioApp(vm: AppViewModel) {
    BackHandler(enabled = vm.screen != Screen.HOME) {
        when (vm.screen) {
            Screen.WIZARD -> if (vm.step > 0) vm.back() else vm.exitWizard()
            Screen.PREVIEW, Screen.EDITOR, Screen.KEYSTORES -> vm.screen = Screen.WIZARD
            Screen.BUILD -> {
                when (vm.buildState) {
                    is BuildUiState.Running -> vm.cancelBuild()
                    else -> vm.leaveBuild()
                }
            }
            Screen.HOME -> Unit
        }
    }

    Box(Modifier.fillMaxSize().background(Palette.Background)) {
        Box(Modifier.fillMaxSize().safeDrawingPadding()) {
            when (vm.screen) {
                Screen.HOME -> HomeScreen(vm)
                Screen.WIZARD -> WizardScreen(vm)
                Screen.PREVIEW -> PreviewScreen(vm)
                Screen.EDITOR -> EditorScreen(vm)
                Screen.BUILD -> BuildScreen(vm)
                Screen.KEYSTORES -> KeystoreScreen(vm)
            }
        }
        vm.busy?.let { message ->
            Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xA0000000)), contentAlignment = Alignment.Center) {
                Surface(shape = RoundedCornerShape(24.dp), color = Palette.Card) {
                    Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(28.dp), color = Palette.Accent, strokeWidth = 3.dp)
                        Spacer(Modifier.width(16.dp))
                        Text(message, color = Palette.TextPrimary)
                    }
                }
            }
        }
    }
}
