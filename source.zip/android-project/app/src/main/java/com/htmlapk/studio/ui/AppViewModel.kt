package com.htmlapk.studio.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.htmlapk.studio.build.ApkBuilder
import com.htmlapk.studio.build.BuildStage
import com.htmlapk.studio.data.ApkRepository
import com.htmlapk.studio.data.ContentImporter
import com.htmlapk.studio.data.DistinguishedName
import com.htmlapk.studio.data.IconProcessor
import com.htmlapk.studio.data.KeystoreInfo
import com.htmlapk.studio.data.KeystoreRepository
import com.htmlapk.studio.data.ProjectRepository
import com.htmlapk.studio.model.BuiltApk
import com.htmlapk.studio.model.Project
import com.htmlapk.studio.model.Rules
import com.htmlapk.studio.model.SourceType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Screen { HOME, WIZARD, PREVIEW, EDITOR, BUILD, KEYSTORES }

sealed interface BuildUiState {
    data object Idle : BuildUiState
    data class Running(val stage: BuildStage, val log: List<String>) : BuildUiState
    data class Success(val apk: BuiltApk, val log: List<String>) : BuildUiState
    data class Failed(val message: String, val log: List<String>) : BuildUiState
}

object Steps {
    val names = listOf("Info", "Content", "Display", "Permissions", "Icon", "Splash", "WebView", "Summary", "Output")
    const val COUNT = 9
    const val INFO = 0
    const val CONTENT = 1
    const val DISPLAY = 2
    const val PERMISSIONS = 3
    const val ICON = 4
    const val SPLASH = 5
    const val WEBVIEW = 6
    const val SUMMARY = 7
    const val OUTPUT = 8
}

class AppViewModel(private val app: Application) : AndroidViewModel(app) {

    val projectRepo = ProjectRepository(app)
    val apkRepo = ApkRepository(app)
    val keystoreRepo = KeystoreRepository(app)
    private val builder = ApkBuilder(app, projectRepo, keystoreRepo, apkRepo)

    var screen by mutableStateOf(Screen.HOME)
    var projects by mutableStateOf<List<Project>>(emptyList())
    var apks by mutableStateOf<List<BuiltApk>>(emptyList())

    var draft by mutableStateOf<Project?>(null)
    var step by mutableIntStateOf(0)

    /** Bumped whenever content / icon files change on disk so previews and checks refresh. */
    var contentVersion by mutableIntStateOf(0)
    var iconVersion by mutableIntStateOf(0)
    var splashVersion by mutableIntStateOf(0)

    var entryCandidates by mutableStateOf<List<String>>(emptyList())
    var busy by mutableStateOf<String?>(null)

    var buildState by mutableStateOf<BuildUiState>(BuildUiState.Idle)
    private var buildJob: Job? = null

    var keystores by mutableStateOf<List<KeystoreInfo>>(emptyList())

    init {
        refresh()
    }

    fun toast(msg: String) {
        Toast.makeText(app, msg, Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------------------------------------ home

    fun refresh() {
        viewModelScope.launch {
            val (p, a) = withContext(Dispatchers.IO) { projectRepo.list() to apkRepo.list() }
            projects = p
            apks = a
        }
    }

    fun deleteProject(p: Project) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { projectRepo.delete(p.id) }
            refresh()
        }
    }

    fun deleteApk(a: BuiltApk) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { apkRepo.delete(a) }
            refresh()
        }
    }

    fun apkFile(a: BuiltApk): File = apkRepo.file(a.fileName)

    // ------------------------------------------------------------------------------------------ wizard

    fun startNew() {
        draft = projectRepo.newProject()
        entryCandidates = emptyList()
        step = 0
        screen = Screen.WIZARD
    }

    fun open(p: Project) {
        draft = p
        step = 0
        entryCandidates = if (p.sourceType == SourceType.ZIP) ContentImporter.listHtmlFiles(projectRepo.wwwDir(p.id)) else emptyList()
        contentVersion++
        iconVersion++
        splashVersion++
        screen = Screen.WIZARD
    }

    fun update(transform: (Project) -> Project) {
        draft = draft?.let(transform)
    }

    fun persist() {
        val p = draft ?: return
        viewModelScope.launch(Dispatchers.IO) { projectRepo.save(p) }
    }

    fun stepValid(index: Int, p: Project): Boolean = when (index) {
        Steps.INFO -> Rules.infoValid(p)
        Steps.CONTENT -> Rules.contentValid(p)
        else -> true
    }

    fun next() {
        val p = draft ?: return
        if (!stepValid(step, p)) return
        persist()
        if (step < Steps.COUNT - 1) step++
    }

    fun back() {
        persist()
        if (step > 0) step--
    }

    fun goToStep(i: Int) {
        persist()
        step = i.coerceIn(0, Steps.COUNT - 1)
    }

    fun exitWizard() {
        persist()
        draft = null
        screen = Screen.HOME
        refresh()
    }

    fun wwwDir(): File = projectRepo.wwwDir(draft?.id ?: "none")

    /** The file that the Edit HTML button opens. */
    fun editableFile(): File? {
        val p = draft ?: return null
        if (p.sourceType == SourceType.URL) return null
        val rel = if (p.sourceType == SourceType.HTML) "index.html" else p.entryFile
        return File(wwwDir(), rel).takeIf { it.isFile }
    }

    // ------------------------------------------------------------------------------------------ content

    fun setSourceType(t: SourceType) {
        update { p ->
            if (p.sourceType == t) p
            else p.copy(sourceType = t, hasContent = false, contentName = "", entryFile = "index.html")
        }
        entryCandidates = emptyList()
    }

    private fun runImport(message: String, block: suspend (Project) -> Project) {
        val current = draft ?: return
        viewModelScope.launch {
            busy = message
            try {
                val updated = withContext(Dispatchers.IO) { block(current) }
                draft = updated
                contentVersion++
                persist()
            } catch (e: Exception) {
                Log.e("Studio", "import failed", e)
                toast("Import failed: ${e.message}")
            } finally {
                busy = null
            }
        }
    }

    fun importHtml(uri: Uri) = runImport("Importing HTML…") { p ->
        val name = ContentImporter.displayName(app, uri)
        ContentImporter.importHtml(app, uri, projectRepo.wwwDir(p.id))
        entryCandidates = emptyList()
        p.copy(sourceType = SourceType.HTML, contentName = name, hasContent = true, entryFile = "index.html")
    }

    fun importZip(uri: Uri) = runImport("Extracting ZIP…") { p ->
        val name = ContentImporter.displayName(app, uri)
        val files = ContentImporter.importZip(app, uri, projectRepo.wwwDir(p.id))
        if (files.isEmpty()) throw IllegalStateException("No .html file found in the ZIP")
        entryCandidates = files
        p.copy(sourceType = SourceType.ZIP, contentName = name, hasContent = true, entryFile = files.first())
    }

    fun importFolder(uri: Uri) = runImport("Copying folder…") { p ->
        val files = ContentImporter.importFolder(app, uri, projectRepo.wwwDir(p.id))
        if (files.isEmpty()) throw IllegalStateException("No .html file found in the folder")
        val name = androidx.documentfile.provider.DocumentFile.fromTreeUri(app, uri)?.name ?: "folder"
        entryCandidates = files
        p.copy(sourceType = SourceType.ZIP, contentName = "$name/", hasContent = true, entryFile = files.first())
    }

    fun saveEditedFile(file: File, text: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { file.writeText(text, Charsets.UTF_8) }
            contentVersion++
            toast("Saved")
        }
    }

    // ------------------------------------------------------------------------------------------ images

    fun saveIcon(bitmap: Bitmap?) {
        val p = draft ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val f = projectRepo.iconFile(p.id)
                if (bitmap == null) f.delete() else IconProcessor.savePng(IconProcessor.scaleDown(bitmap, 512), f)
            }
            update { it.copy(hasIcon = bitmap != null) }
            iconVersion++
            persist()
        }
    }

    fun saveSplashImage(bitmap: Bitmap?) {
        val p = draft ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val f = projectRepo.splashFile(p.id)
                if (bitmap == null) f.delete() else IconProcessor.savePng(IconProcessor.scaleDown(bitmap, 512), f)
            }
            update { it.copy(hasSplashImage = bitmap != null) }
            splashVersion++
            persist()
        }
    }

    // ------------------------------------------------------------------------------------------ build

    fun startBuild() {
        val p = draft ?: return
        if (buildState is BuildUiState.Running) return
        val logs = ArrayList<String>()
        fun snapshot(): List<String> = synchronized(logs) { logs.toList() }
        buildState = BuildUiState.Running(BuildStage.PREPARING, emptyList())
        screen = Screen.BUILD
        buildJob = viewModelScope.launch {
            var stage = BuildStage.PREPARING
            try {
                val saved = withContext(Dispatchers.IO) { projectRepo.save(p) }
                val built = builder.build(
                    saved,
                    log = { line ->
                        synchronized(logs) { logs.add(line) }
                        buildState = BuildUiState.Running(stage, snapshot())
                    },
                    onStage = { st ->
                        stage = st
                        buildState = BuildUiState.Running(st, snapshot())
                    }
                )
                if (p.autoIncrement) {
                    val bumped = p.copy(versionCode = (built.versionCode + 1).toString())
                    draft = withContext(Dispatchers.IO) { projectRepo.save(bumped) }
                }
                buildState = BuildUiState.Success(built, snapshot())
                refresh()
            } catch (e: CancellationException) {
                buildState = BuildUiState.Idle
                screen = Screen.WIZARD
                throw e
            } catch (e: Throwable) {
                Log.e("Studio", "build failed", e)
                synchronized(logs) { logs.add("ERROR: " + Log.getStackTraceString(e)) }
                buildState = BuildUiState.Failed(e.message ?: e.javaClass.simpleName, snapshot())
            }
        }
    }

    fun cancelBuild() {
        buildJob?.cancel()
    }

    fun leaveBuild() {
        buildState = BuildUiState.Idle
        screen = if (draft != null) Screen.WIZARD else Screen.HOME
        if (draft == null) refresh()
    }

    // ------------------------------------------------------------------------------------------ keystores

    fun reloadKeystores() {
        viewModelScope.launch {
            try {
                keystores = withContext(Dispatchers.IO) {
                    keystoreRepo.ensureDefault()
                    keystoreRepo.list().sortedWith(compareByDescending<KeystoreInfo> { it.isDefault }.thenBy { it.name })
                }
            } catch (e: Exception) {
                toast("Keystore error: ${e.message}")
            }
        }
    }

    fun createKeystore(name: String, alias: String, password: String, years: Int, dn: DistinguishedName) {
        viewModelScope.launch {
            busy = "Generating keys…"
            try {
                withContext(Dispatchers.IO) { keystoreRepo.create(name, alias, password, years, dn) }
                toast("Keystore created")
            } catch (e: Exception) {
                toast("Could not create keystore: ${e.message}")
            } finally {
                busy = null
            }
            reloadKeystores()
        }
    }

    fun importKeystore(uri: Uri, name: String, alias: String, storePass: String, keyPass: String) {
        viewModelScope.launch {
            busy = "Importing keystore…"
            try {
                withContext(Dispatchers.IO) { keystoreRepo.importKeystore(app, uri, name, alias, storePass, keyPass) }
                toast("Keystore imported")
            } catch (e: Exception) {
                toast(e.message ?: "Import failed")
            } finally {
                busy = null
            }
            reloadKeystores()
        }
    }

    fun exportKeystore(info: KeystoreInfo, uri: Uri) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { keystoreRepo.export(info, uri) }
                toast("Keystore exported")
            } catch (e: Exception) {
                toast("Export failed: ${e.message}")
            }
        }
    }

    fun deleteKeystore(info: KeystoreInfo) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { keystoreRepo.delete(info.id) }
            update { if (it.keystoreId == info.id) it.copy(keystoreId = KeystoreRepository.DEFAULT_ID) else it }
            reloadKeystores()
        }
    }
}
