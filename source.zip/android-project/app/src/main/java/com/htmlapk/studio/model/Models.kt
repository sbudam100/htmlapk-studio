package com.htmlapk.studio.model

import kotlinx.serialization.Serializable

enum class SourceType(val label: String) {
    HTML("HTML File"),
    ZIP("ZIP / Folder of web files"),
    URL("Website URL")
}

enum class Orientation(val label: String, val key: String) {
    PORTRAIT("Portrait", "portrait"),
    LANDSCAPE("Landscape", "landscape"),
    AUTO("Auto-rotate", "auto")
}

enum class ThemeMode(val label: String, val key: String) {
    AUTO("Automatic", "auto"),
    NIGHT("Night", "night"),
    DAY("Day", "day")
}

enum class LoaderStyle(val label: String, val key: String) {
    RING("Ring", "ring"),
    BAR("Bar", "bar"),
    NONE("None", "none")
}

enum class CacheMode(val label: String, val key: String) {
    DEFAULT("Load Default", "default"),
    NO_CACHE("No Cache", "no_cache"),
    CACHE_ELSE_NETWORK("Cache Else Network", "cache_else_network"),
    CACHE_ONLY("Cache Only", "cache_only")
}

enum class MixedContentMode(val label: String, val key: String) {
    COMPATIBILITY("Compatibility Mode", "compatibility"),
    NEVER("Never Allow", "never"),
    ALWAYS("Always Allow", "always")
}

@Serializable
data class SplashSettings(
    val enabled: Boolean = false,
    val backgroundColor: Int = 0xFF0F172A.toInt(),
    val loaderColor: Int = 0xFF00E5CC.toInt(),
    val loaderStyle: LoaderStyle = LoaderStyle.RING,
    val iconSizeDp: Int = 120,
    val iconCornerDp: Int = 16,
    val loaderSizeDp: Int = 48,
    val spacingDp: Int = 28,
    val durationMs: Int = 2000,
    val thicknessDp: Int = 4,
    val fadeMs: Int = 400
)

@Serializable
data class NavigationSettings(
    val pullToRefresh: Boolean = false,
    val noInternetDialog: Boolean = false,
    val loadingIndicator: Boolean = false,
    val backHistory: Boolean = true,
    val exitConfirm: Boolean = true,
    val apiOnlyOwnPages: Boolean = true
)

@Serializable
data class WebViewSettings(
    val javaScript: Boolean = true,
    val domStorage: Boolean = true,
    val fileAccess: Boolean = false,
    val contentAccess: Boolean = false,
    val universalFileAccess: Boolean = false,
    val fileAccessFromFileUrls: Boolean = false,
    val builtInZoom: Boolean = true,
    val wideViewport: Boolean = true,
    val overviewMode: Boolean = true,
    val geolocation: Boolean = false,
    val cacheMode: CacheMode = CacheMode.DEFAULT,
    val mixedContent: MixedContentMode = MixedContentMode.COMPATIBILITY
)

@Serializable
data class Project(
    val id: String,
    // Step 1: Info
    val appName: String = "",
    val packageName: String = "com.htmlapk.",
    val packageEdited: Boolean = false,
    val versionCode: String = "1",
    val versionName: String = "1.0",
    val autoIncrement: Boolean = false,
    val minSdk: String = "24",
    val targetSdk: String = "36",
    val maxSdk: String = "",
    val customScheme: String = "",
    // Step 2: Content
    val sourceType: SourceType = SourceType.HTML,
    val contentName: String = "",
    val entryFile: String = "index.html",
    val websiteUrl: String = "",
    val hasContent: Boolean = false,
    // Step 3: Display
    val orientation: Orientation = Orientation.PORTRAIT,
    val statusBarVisible: Boolean = true,
    val actionBarVisible: Boolean = false,
    val keepScreenOn: Boolean = false,
    val cutout: Boolean = false,
    val desktopMode: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.AUTO,
    val barColor: Int = 0xFF2196F3.toInt(),
    val loadingBackground: Int = 0xFFFFFFFF.toInt(),
    // Step 4: Permissions
    val permissions: Set<String> = setOf(
        "android.permission.INTERNET",
        "android.permission.ACCESS_NETWORK_STATE",
        "android.permission.VIBRATE"
    ),
    // Step 5/6: Icon + Splash
    val hasIcon: Boolean = false,
    val splash: SplashSettings = SplashSettings(),
    val hasSplashImage: Boolean = false,
    // Step 7: WebView
    val navigation: NavigationSettings = NavigationSettings(),
    val webView: WebViewSettings = WebViewSettings(),
    // Step 9: Output
    val keystoreId: String = "default",
    val updatedAt: Long = 0L
)

@Serializable
data class BuiltApk(
    val fileName: String,
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Int,
    val sizeBytes: Long,
    val createdAt: Long
)

data class PermissionDef(
    val title: String,
    val description: String,
    val id: String,
    /** Written as android:maxSdkVersion so the manifest stays valid on new Android versions. */
    val maxSdk: Int? = null
)

object Permissions {
    val all = listOf(
        PermissionDef("Internet", "Web pages, URL content and external API calls", "android.permission.INTERNET"),
        PermissionDef("Network State", "Check whether the device is online", "android.permission.ACCESS_NETWORK_STATE"),
        PermissionDef("Read Storage", "Local HTML files and output", "android.permission.READ_EXTERNAL_STORAGE", maxSdk = 32),
        PermissionDef("Write Storage", "Local HTML files and output", "android.permission.WRITE_EXTERNAL_STORAGE", maxSdk = 28),
        PermissionDef("Read Images", "Access photos on Android 13+", "android.permission.READ_MEDIA_IMAGES"),
        PermissionDef("Read Videos", "Access videos on Android 13+", "android.permission.READ_MEDIA_VIDEO"),
        PermissionDef("Read Audio", "Access music and audio files on Android 13+", "android.permission.READ_MEDIA_AUDIO"),
        PermissionDef("Camera", "Camera access for web apps", "android.permission.CAMERA"),
        PermissionDef("Microphone", "Audio recording for apps", "android.permission.RECORD_AUDIO"),
        PermissionDef("Precise Location", "Precise location access", "android.permission.ACCESS_FINE_LOCATION"),
        PermissionDef("Approximate Location", "Approximate location access", "android.permission.ACCESS_COARSE_LOCATION"),
        PermissionDef("Notifications", "Show push notifications on Android 13+", "android.permission.POST_NOTIFICATIONS"),
        PermissionDef("Exact Alarms", "Send notifications at exact scheduled times", "android.permission.SCHEDULE_EXACT_ALARM"),
        PermissionDef("Activity Recognition", "Step counter and physical activity sensors", "android.permission.ACTIVITY_RECOGNITION"),
        PermissionDef("Vibration", "Control the device vibration motor", "android.permission.VIBRATE"),
        PermissionDef("Phone State", "Read phone state", "android.permission.READ_PHONE_STATE")
    )

    fun byId(id: String): PermissionDef? = all.firstOrNull { it.id == id }
}

/** Pure validation / formatting helpers shared by the wizard UI and the build pipeline. */
object Rules {
    private val javaKeywords = setOf(
        "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue",
        "default", "do", "double", "else", "enum", "extends", "final", "finally", "float", "for", "goto", "if",
        "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "package", "private",
        "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
        "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null"
    )
    private val segment = Regex("^[a-z][a-z0-9_]*$")
    private val schemeRegex = Regex("^[a-z][a-z0-9+.\\-]*$")

    fun defaultPackage(appName: String): String {
        var s = appName.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }
        if (s.isEmpty()) s = "app"
        if (s[0].isDigit()) s = "app$s"
        return "com.htmlapk.$s"
    }

    fun isValidPackage(pkg: String): Boolean {
        val parts = pkg.split('.')
        if (parts.size < 2) return false
        return parts.all { segment.matches(it) && it !in javaKeywords }
    }

    fun isValidScheme(s: String): Boolean = s.isEmpty() || (schemeRegex.matches(s) && s !in setOf("http", "https", "file", "content", "javascript", "intent"))

    fun androidName(api: Int?): String = when (api) {
        null -> ""
        21 -> "Android 5.0"
        22 -> "Android 5.1"
        23 -> "Android 6.0"
        24 -> "Android 7.0"
        25 -> "Android 7.1"
        26 -> "Android 8.0"
        27 -> "Android 8.1"
        28 -> "Android 9"
        29 -> "Android 10"
        30 -> "Android 11"
        31 -> "Android 12"
        32 -> "Android 12L"
        33 -> "Android 13"
        34 -> "Android 14"
        35 -> "Android 15"
        36 -> "Android 16"
        else -> if (api > 36) "Newer than Android 16" else "Unknown"
    }

    /** The template's real minSdk is 21, and 36 is the highest platform this builder knows. */
    const val MIN_SDK_LOWEST = 21
    const val SDK_HIGHEST = 36

    fun minSdkError(p: Project): String? {
        val v = p.minSdk.toIntOrNull() ?: return "Enter a number"
        if (v < MIN_SDK_LOWEST || v > SDK_HIGHEST) return "Use $MIN_SDK_LOWEST–$SDK_HIGHEST"
        return null
    }

    fun targetSdkError(p: Project): String? {
        val v = p.targetSdk.toIntOrNull() ?: return "Enter a number"
        if (v < MIN_SDK_LOWEST || v > SDK_HIGHEST) return "Use $MIN_SDK_LOWEST–$SDK_HIGHEST"
        val min = p.minSdk.toIntOrNull()
        if (min != null && v < min) return "Must be ≥ min SDK"
        return null
    }

    fun maxSdkError(p: Project): String? {
        if (p.maxSdk.isBlank()) return null
        val v = p.maxSdk.toIntOrNull() ?: return "Enter a number or leave empty"
        val min = p.minSdk.toIntOrNull() ?: return null
        if (v < min) return "Must be ≥ min SDK"
        return null
    }

    fun versionCodeError(p: Project): String? {
        val v = p.versionCode.toIntOrNull() ?: return "Enter a whole number"
        return if (v < 1) "Must be at least 1" else null
    }

    fun urlError(p: Project): String? {
        val u = p.websiteUrl.trim()
        return if (u.startsWith("https://") || u.startsWith("http://")) {
            if (u.substringAfter("://").isBlank()) "Enter a full address" else null
        } else "Start with https:// or http://"
    }

    fun infoValid(p: Project): Boolean =
        p.appName.isNotBlank() && isValidPackage(p.packageName) &&
            versionCodeError(p) == null && p.versionName.isNotBlank() &&
            minSdkError(p) == null && targetSdkError(p) == null && maxSdkError(p) == null &&
            isValidScheme(p.customScheme)

    fun contentValid(p: Project): Boolean =
        if (p.sourceType == SourceType.URL) urlError(p) == null else p.hasContent

    /** Permissions that will really be written to the manifest (a URL app always needs INTERNET). */
    fun effectivePermissions(p: Project): Set<String> =
        if (p.sourceType == SourceType.URL) p.permissions + "android.permission.INTERNET" else p.permissions

    fun enabledWebOptions(p: Project): Int {
        val w = p.webView
        val n = p.navigation
        return listOf(
            w.javaScript, w.domStorage, w.fileAccess, w.contentAccess, w.universalFileAccess, w.fileAccessFromFileUrls,
            w.builtInZoom, w.wideViewport, w.overviewMode, w.geolocation,
            n.pullToRefresh, n.noInternetDialog, n.loadingIndicator, n.backHistory, n.exitConfirm, n.apiOnlyOwnPages
        ).count { it }
    }

    fun hex(color: Int): String = String.format("#%06X", 0xFFFFFF and color)
}
