package com.htmlapk.studio.data

import android.content.Context
import com.htmlapk.studio.model.BuiltApk
import com.htmlapk.studio.model.Project
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

val AppJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    prettyPrint = true
}

/**
 * Projects are plain folders under filesDir/projects/<id>/:
 *   project.json  the wizard state
 *   www/          the user's web files (index.html or the extracted ZIP / copied folder)
 *   icon.png      the processed square app icon (max 512 px)
 *   splash.png    optional custom splash image
 */
class ProjectRepository(private val context: Context) {

    private val root: File get() = File(context.filesDir, "projects").also { it.mkdirs() }

    fun dir(id: String) = File(root, id)
    fun wwwDir(id: String) = File(dir(id), "www")
    fun iconFile(id: String) = File(dir(id), "icon.png")
    fun splashFile(id: String) = File(dir(id), "splash.png")
    private fun jsonFile(id: String) = File(dir(id), "project.json")

    fun newProject(): Project = Project(id = UUID.randomUUID().toString().take(12))

    fun list(): List<Project> =
        (root.listFiles() ?: emptyArray())
            .filter { it.isDirectory }
            .mapNotNull { load(it.name) }
            .sortedByDescending { it.updatedAt }

    fun load(id: String): Project? = try {
        AppJson.decodeFromString<Project>(jsonFile(id).readText())
    } catch (e: Exception) {
        null
    }

    fun save(p: Project): Project {
        val saved = p.copy(updatedAt = System.currentTimeMillis())
        dir(p.id).mkdirs()
        val tmp = File(dir(p.id), "project.json.tmp")
        tmp.writeText(AppJson.encodeToString(saved))
        tmp.renameTo(jsonFile(p.id))
        return saved
    }

    fun delete(id: String) {
        dir(id).deleteRecursively()
    }
}

/** Finished APKs: filesDir/apks/<name>.apk with a <name>.json metadata file next to each one. */
class ApkRepository(private val context: Context) {

    val dir: File get() = File(context.filesDir, "apks").also { it.mkdirs() }

    fun file(fileName: String) = File(dir, fileName)

    fun list(): List<BuiltApk> =
        (dir.listFiles { f -> f.extension == "json" } ?: emptyArray())
            .mapNotNull {
                try {
                    AppJson.decodeFromString<BuiltApk>(it.readText())
                } catch (e: Exception) {
                    null
                }
            }
            .filter { file(it.fileName).exists() }
            .sortedByDescending { it.createdAt }

    fun register(built: BuiltApk) {
        File(dir, built.fileName.removeSuffix(".apk") + ".json").writeText(AppJson.encodeToString(built))
    }

    fun delete(built: BuiltApk) {
        file(built.fileName).delete()
        File(dir, built.fileName.removeSuffix(".apk") + ".json").delete()
    }
}
