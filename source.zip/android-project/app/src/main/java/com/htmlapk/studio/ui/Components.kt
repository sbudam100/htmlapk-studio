package com.htmlapk.studio.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.htmlapk.studio.model.Rules

/** Large rounded dark-grey surface used for wizard content and list items. */
@Composable
fun StudioCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(modifier = modifier, shape = RoundedCornerShape(28.dp), color = Palette.Card) {
        content()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun Helper(text: String, modifier: Modifier = Modifier, color: Color = Palette.TextSecondary) {
    Text(text, modifier = modifier, color = color, fontSize = 13.sp, lineHeight = 18.sp)
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Palette.Accent,
    unfocusedBorderColor = Palette.Outline,
    focusedLabelColor = Palette.Accent,
    unfocusedLabelColor = Palette.TextSecondary,
    cursorColor = Palette.Accent,
    focusedTextColor = Palette.TextPrimary,
    unfocusedTextColor = Palette.TextPrimary,
    errorBorderColor = Palette.Error,
    errorLabelColor = Palette.Error,
    focusedContainerColor = Color.Transparent,
    unfocusedContainerColor = Color.Transparent
)

/** Outlined text field with a floating label and helper text underneath. */
@Composable
fun StudioField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    helper: String? = null,
    extraHelper: String? = null,
    error: String? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    enabled: Boolean = true,
    placeholder: String? = null,
    minLines: Int = 1,
    visual: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        placeholder = placeholder?.let { { Text(it, color = Palette.TextSecondary) } },
        singleLine = singleLine,
        minLines = minLines,
        enabled = enabled,
        isError = error != null,
        keyboardOptions = KeyboardOptions(keyboardType = if (visual) KeyboardType.Password else keyboardType),
        visualTransformation = if (visual) PasswordVisualTransformation() else VisualTransformation.None,
        shape = RoundedCornerShape(16.dp),
        colors = fieldColors(),
        supportingText = if (helper != null || error != null || extraHelper != null) {
            {
                Column {
                    if (error != null) Text(error, color = Palette.Error)
                    else if (helper != null) Text(helper, color = Palette.TextSecondary)
                    if (extraHelper != null) Text(extraHelper, color = Palette.Accent)
                }
            }
        } else null
    )
}

@Composable
fun CheckRow(
    title: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    extra: String? = null,
    enabled: Boolean = true
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = enabled) { onChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = null,
            enabled = enabled,
            colors = CheckboxDefaults.colors(
                checkedColor = Palette.Accent,
                checkmarkColor = Palette.OnAccent,
                uncheckedColor = Palette.TextSecondary
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) Helper(subtitle)
            if (extra != null) Text(extra, color = Palette.Accent, fontSize = 12.sp)
        }
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier, subtitle: String? = null) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onChange(!checked) }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Palette.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) Helper(subtitle)
        }
        Switch(
            checked = checked,
            onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Palette.OnAccent,
                checkedTrackColor = Palette.Accent,
                uncheckedThumbColor = Palette.TextSecondary,
                uncheckedTrackColor = Palette.CardHigh,
                uncheckedBorderColor = Palette.Outline
            )
        )
    }
}

/** Dropdown. [disabledIndexes] are shown greyed out and cannot be selected. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownField(
    label: String,
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    helper: String? = null,
    disabledIndexes: Set<Int> = emptySet()
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }, modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = options.getOrElse(selectedIndex) { "" },
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = fieldColors(),
            supportingText = helper?.let { { Text(it, color = Palette.TextSecondary) } }
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            containerColor = Palette.CardHigh
        ) {
            options.forEachIndexed { i, text ->
                val enabled = i !in disabledIndexes
                DropdownMenuItem(
                    text = { Text(text, color = if (enabled) Palette.TextPrimary else Palette.TextSecondary) },
                    enabled = enabled,
                    onClick = { expanded = false; onSelect(i) }
                )
            }
        }
    }
}

@Composable
fun SegmentedRow(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    disabledIndexes: Set<Int> = emptySet()
) {
    SingleChoiceSegmentedButtonRow(modifier = modifier.fillMaxWidth()) {
        options.forEachIndexed { i, text ->
            SegmentedButton(
                selected = i == selectedIndex,
                onClick = { onSelect(i) },
                enabled = i !in disabledIndexes,
                shape = SegmentedButtonDefaults.itemShape(index = i, count = options.size),
                colors = SegmentedButtonDefaults.colors(
                    activeContainerColor = Palette.Accent,
                    activeContentColor = Palette.OnAccent,
                    inactiveContainerColor = Color.Transparent,
                    inactiveContentColor = Palette.TextPrimary,
                    activeBorderColor = Palette.Accent,
                    inactiveBorderColor = Palette.Outline,
                    disabledInactiveContentColor = Palette.TextSecondary,
                    disabledInactiveBorderColor = Palette.Outline,
                    disabledInactiveContainerColor = Color.Transparent
                )
            ) { Text(text, maxLines = 1) }
        }
    }
}

/** Slider with its current value shown on the right. */
@Composable
fun SliderRow(
    label: String,
    value: Int,
    range: IntRange,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    format: (Int) -> String = { it.toString() },
    step: Int = 1
) {
    Column(modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Palette.TextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(format(value), color = Palette.Accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        val steps = ((range.last - range.first) / step - 1).coerceAtLeast(0)
        Slider(
            value = value.toFloat(),
            onValueChange = { v ->
                val snapped = (Math.round((v - range.first) / step) * step + range.first).coerceIn(range.first, range.last)
                if (snapped != value) onChange(snapped)
            },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = Palette.Accent,
                activeTrackColor = Palette.Accent,
                inactiveTrackColor = Palette.Outline,
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            )
        )
    }
}

/** Row of circular colour swatches with a check on the selected one, plus an optional custom colour picker. */
@Composable
fun SwatchRow(
    colors: List<Int>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    allowCustom: Boolean = false
) {
    var showPicker by remember { mutableStateOf(false) }
    val isCustom = colors.none { it == selected }
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        colors.forEach { c ->
            Swatch(c, selected == c) { onSelect(c) }
        }
        if (allowCustom) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (isCustom) Color(selected) else Palette.CardHigh)
                    .border(BorderStroke(if (isCustom) 3.dp else 1.dp, if (isCustom) Palette.Accent else Palette.Outline), CircleShape)
                    .clickable { showPicker = true },
                contentAlignment = Alignment.Center
            ) {
                if (isCustom) Icon(Icons.Filled.Check, null, tint = checkTint(selected), modifier = Modifier.size(20.dp))
                else Text("+", color = Palette.TextPrimary, fontSize = 20.sp)
            }
        }
    }
    if (showPicker) ColorPickerDialog(selected, { showPicker = false }) { onSelect(it); showPicker = false }
}

private fun checkTint(color: Int): Color =
    if (androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.55) Color.Black else Color.White

@Composable
private fun Swatch(color: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(color))
            .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) Palette.Accent else Palette.Outline), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (selected) Icon(Icons.Filled.Check, null, tint = checkTint(color), modifier = Modifier.size(20.dp))
    }
}

@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    var r by remember { mutableStateOf((initial shr 16) and 0xFF) }
    var g by remember { mutableStateOf((initial shr 8) and 0xFF) }
    var b by remember { mutableStateOf(initial and 0xFF) }
    var hex by remember { mutableStateOf(Rules.hex(initial)) }
    val color = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Card,
        title = { Text("Custom color", color = Palette.TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(color))
                        .border(BorderStroke(1.dp, Palette.Outline), RoundedCornerShape(12.dp))
                )
                SliderRow("Red", r, 0..255, { r = it; hex = Rules.hex((0xFF shl 24) or (it shl 16) or (g shl 8) or b) })
                SliderRow("Green", g, 0..255, { g = it; hex = Rules.hex((0xFF shl 24) or (r shl 16) or (it shl 8) or b) })
                SliderRow("Blue", b, 0..255, { b = it; hex = Rules.hex((0xFF shl 24) or (r shl 16) or (g shl 8) or it) })
                StudioField(
                    label = "Hex", value = hex,
                    onValueChange = { v ->
                        hex = v
                        val clean = v.trim().removePrefix("#")
                        if (clean.length == 6) clean.toIntOrNull(16)?.let { rgb ->
                            r = (rgb shr 16) and 0xFF; g = (rgb shr 8) and 0xFF; b = rgb and 0xFF
                        }
                    }
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick(color) }) { Text("Select", color = Palette.Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.TextSecondary) } }
    )
}

@Composable
fun StatusBox(ok: Boolean, lines: List<String>, modifier: Modifier = Modifier) {
    val tint = if (ok) Palette.Success else Color(0xFFFBBF24)
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(tint.copy(alpha = 0.12f))
            .border(BorderStroke(1.dp, tint.copy(alpha = 0.5f)), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(if (ok) "✓" else "!", color = tint, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            lines.forEach { Text(it, color = Palette.TextPrimary, fontSize = 14.sp, lineHeight = 20.sp) }
        }
    }
}

@Composable
fun Gap(h: Int = 12) = Spacer(Modifier.height(h.dp))

@Composable
fun accentTextStyleColor() = MaterialTheme.colorScheme.primary
