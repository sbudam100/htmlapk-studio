package com.htmlapk.studio.data

import org.bouncycastle.asn1.x500.X500NameBuilder
import org.bouncycastle.asn1.x500.style.BCStyle
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** Pure-JVM keystore helpers (BouncyCastle). No Android classes, so they are covered by unit tests. */
object KeyTools {
    /** Used as an explicit provider instance: Android's built-in "BC" provider is stripped down. */
    val BC = BouncyCastleProvider()

    class Generated(val bytes: ByteArray, val subject: String, val validUntil: Long)

    /** Self-signed RSA-2048 / SHA256withRSA certificate in a PKCS12 keystore (key password = store password). */
    fun generate(alias: String, password: String, years: Int, dn: DistinguishedName, fallbackName: String): Generated {
        val builder = X500NameBuilder(BCStyle.INSTANCE)
        builder.addRDN(BCStyle.CN, dn.commonName.ifBlank { fallbackName.ifBlank { "Android" } })
        if (dn.organizationalUnit.isNotBlank()) builder.addRDN(BCStyle.OU, dn.organizationalUnit)
        if (dn.organization.isNotBlank()) builder.addRDN(BCStyle.O, dn.organization)
        if (dn.locality.isNotBlank()) builder.addRDN(BCStyle.L, dn.locality)
        if (dn.state.isNotBlank()) builder.addRDN(BCStyle.ST, dn.state)
        if (dn.country.isNotBlank()) builder.addRDN(BCStyle.C, dn.country.take(2).uppercase())
        val name = builder.build()

        val kpg = KeyPairGenerator.getInstance("RSA", BC)
        kpg.initialize(2048, SecureRandom())
        val pair = kpg.generateKeyPair()

        val now = System.currentTimeMillis()
        val notAfter = Date(now + years.coerceIn(1, 100) * 365L * 24 * 3600 * 1000)
        val serial = BigInteger(64, SecureRandom()).abs().add(BigInteger.ONE)
        val holder = JcaX509v3CertificateBuilder(name, serial, Date(now - 24L * 3600 * 1000), notAfter, name, pair.public)
            .build(JcaContentSignerBuilder("SHA256withRSA").setProvider(BC).build(pair.private))
        val cert = JcaX509CertificateConverter().setProvider(BC).getCertificate(holder)

        val ks = KeyStore.getInstance("PKCS12", BC)
        ks.load(null, null)
        ks.setKeyEntry(alias, pair.private, password.toCharArray(), arrayOf(cert))
        val out = ByteArrayOutputStream()
        ks.store(out, password.toCharArray())
        return Generated(out.toByteArray(), cert.subjectX500Principal.name, cert.notAfter.time)
    }

    /** Opens PKCS12 first, then BKS. Returns the store and its type. */
    fun open(bytes: ByteArray, storePassword: String): Pair<KeyStore, String> {
        for (type in listOf("PKCS12", "BKS")) {
            try {
                val ks = KeyStore.getInstance(type, BC)
                ks.load(ByteArrayInputStream(bytes), storePassword.toCharArray())
                return ks to type
            } catch (_: Exception) { }
        }
        throw IOException(
            "Could not open this keystore. Check the password. Legacy Java JKS files are not supported on Android; " +
                "convert with: keytool -importkeystore -srckeystore old.jks -destkeystore new.p12 -deststoretype pkcs12"
        )
    }

    fun loadSigner(bytes: ByteArray, type: String, alias: String, storePassword: String, keyPassword: String): SignerMaterial {
        val ks = KeyStore.getInstance(type, BC)
        ks.load(ByteArrayInputStream(bytes), storePassword.toCharArray())
        val key = ks.getKey(alias, keyPassword.toCharArray()) as? PrivateKey ?: throw IOException("Key \"$alias\" not found")
        val chain = ks.getCertificateChain(alias) ?: throw IOException("Certificate chain missing")
        val cf = CertificateFactory.getInstance("X.509")
        val certs = chain.map { cf.generateCertificate(ByteArrayInputStream(it.encoded)) as X509Certificate }
        // Re-create the key with the platform provider so apksig uses the platform's (fast, native) implementation.
        val platformKey = try {
            KeyFactory.getInstance(key.algorithm).generatePrivate(PKCS8EncodedKeySpec(key.encoded))
        } catch (e: Exception) {
            key
        }
        return SignerMaterial(platformKey, certs)
    }
}
