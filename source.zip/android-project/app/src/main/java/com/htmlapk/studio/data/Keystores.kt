package com.htmlapk.studio.data

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import org.bouncycastle.asn1.x500.X500NameBuilder
import org.bouncycastle.asn1.x500.style.BCStyle
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts keystore passwords with an AES-GCM key that never leaves the AndroidKeyStore. */
object SecretBox {
    private const val ALIAS = "htmlapk_keystore_passwords"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + ct, Base64.NO_WRAP)
    }

    fun decrypt(encoded: String): String {
        val raw = Base64.decode(encoded, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12))
        return String(cipher.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
    }
}

@Serializable
data class KeystoreInfo(
    val id: String,
    val name: String,
    val alias: String,
    val fileName: String,
    /** "PKCS12" or "BKS" */
    val type: String,
    val encStorePass: String,
    val encKeyPass: String,
    val createdAt: Long,
    val subject: String = "",
    val validUntil: Long = 0L,
    val isDefault: Boolean = false
)

/** What the APK signer needs. Keys are converted to the platform's own implementation classes. */
class SignerMaterial(val privateKey: PrivateKey, val certificates: List<X509Certificate>)

data class DistinguishedName(
    val commonName: String = "",
    val organization: String = "",
    val organizationalUnit: String = "",
    val locality: String = "",
    val state: String = "",
    val country: String = ""
)

class KeystoreRepository(private val context: Context) {

    companion object {
        const val DEFAULT_ID = "default"
        const val DEFAULT_LABEL = "Default (auto-generated)"
    }

    private val dir: File get() = File(context.filesDir, "keystores").also { it.mkdirs() }
    private val indexFile get() = File(dir, "index.json")

    @Synchronized
    fun list(): List<KeystoreInfo> {
        if (!indexFile.isFile) return emptyList()
        return try {
            AppJson.decodeFromString<List<KeystoreInfo>>(indexFile.readText())
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeIndex(items: List<KeystoreInfo>) {
        indexFile.writeText(AppJson.encodeToString(items))
    }

    fun get(id: String): KeystoreInfo? = list().firstOrNull { it.id == id }

    /** Generates the default keystore on first use and then reuses it for every build, so updates install over old versions. */
    @Synchronized
    fun ensureDefault(): KeystoreInfo {
        get(DEFAULT_ID)?.let { if (File(dir, it.fileName).isFile) return it }
        val password = randomPassword()
        return generate(
            id = DEFAULT_ID, displayName = DEFAULT_LABEL, alias = "htmlapk",
            storePassword = password, years = 30,
            dn = DistinguishedName(commonName = "HTML to APK Studio", organization = "HTML to APK Studio"),
            isDefault = true
        )
    }

    /** Resolves a project's keystore id, creating the default one when needed. Falls back to default if deleted. */
    fun resolve(id: String): KeystoreInfo =
        if (id == DEFAULT_ID) ensureDefault() else (get(id) ?: ensureDefault())

    @Synchronized
    fun create(displayName: String, alias: String, password: String, years: Int, dn: DistinguishedName): KeystoreInfo =
        generate(UUID.randomUUID().toString().take(10), displayName, alias, password, years, dn, false)

    private fun generate(
        id: String, displayName: String, alias: String, storePassword: String, years: Int,
        dn: DistinguishedName, isDefault: Boolean
    ): KeystoreInfo {
        require(alias.isNotBlank()) { "Alias is required" }
        require(storePassword.length >= 6) { "Password must have at least 6 characters" }
        val generated = KeyTools.generate(alias, storePassword, years, dn, displayName)
        val fileName = "$id.p12"
        File(dir, fileName).writeBytes(generated.bytes)

        val info = KeystoreInfo(
            id = id, name = displayName, alias = alias, fileName = fileName, type = "PKCS12",
            encStorePass = SecretBox.encrypt(storePassword), encKeyPass = SecretBox.encrypt(storePassword),
            createdAt = System.currentTimeMillis(), subject = generated.subject, validUntil = generated.validUntil, isDefault = isDefault
        )
        writeIndex(list().filter { it.id != id } + info)
        return info
    }

    /** Imports a .jks / .p12 / .pfx / .bks file. Tries PKCS12 first, then BKS. */
    @Synchronized
    fun importKeystore(context: Context, uri: Uri, displayName: String, alias: String, storePassword: String, keyPassword: String): KeystoreInfo {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Cannot read the file")
        val (ks, type) = KeyTools.open(bytes, storePassword)
        val chosen = alias.ifBlank {
            ks.aliases().toList().firstOrNull { ks.isKeyEntry(it) } ?: throw IOException("The keystore contains no private key")
        }
        if (!ks.isKeyEntry(chosen)) throw IOException("Alias \"$chosen\" is not a private key entry")
        val kp = keyPassword.ifBlank { storePassword }
        try {
            ks.getKey(chosen, kp.toCharArray()) ?: throw IOException("No key for alias \"$chosen\"")
        } catch (e: Exception) {
            throw IOException("Wrong key password for alias \"$chosen\"")
        }
        val cert = ks.getCertificate(chosen) as? X509Certificate ?: throw IOException("No certificate for alias \"$chosen\"")

        val id = UUID.randomUUID().toString().take(10)
        val fileName = "$id.${if (type == "BKS") "bks" else "p12"}"
        File(dir, fileName).writeBytes(bytes)
        val info = KeystoreInfo(
            id = id, name = displayName.ifBlank { chosen }, alias = chosen, fileName = fileName, type = type,
            encStorePass = SecretBox.encrypt(storePassword), encKeyPass = SecretBox.encrypt(kp),
            createdAt = System.currentTimeMillis(), subject = cert.subjectX500Principal.name, validUntil = cert.notAfter.time
        )
        writeIndex(list() + info)
        return info
    }

    fun export(info: KeystoreInfo, uri: Uri) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            File(dir, info.fileName).inputStream().use { it.copyTo(out) }
        } ?: throw IOException("Cannot write to the selected location")
    }

    /** The default keystore cannot be deleted: doing so would stop future updates from installing over old builds. */
    @Synchronized
    fun delete(id: String) {
        val info = get(id) ?: return
        if (info.isDefault) return
        File(dir, info.fileName).delete()
        writeIndex(list().filter { it.id != id })
    }

    fun passwords(info: KeystoreInfo): Pair<String, String> =
        SecretBox.decrypt(info.encStorePass) to SecretBox.decrypt(info.encKeyPass)

    fun loadSigner(info: KeystoreInfo): SignerMaterial {
        val (sp, kp) = passwords(info)
        return KeyTools.loadSigner(File(dir, info.fileName).readBytes(), info.type, info.alias, sp, kp)
    }

    private fun randomPassword(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
        val rnd = SecureRandom()
        return (1..24).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
    }
}
