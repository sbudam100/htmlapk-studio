package com.htmlapk.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.htmlapk.studio.model.BuiltApk
import com.htmlapk.studio.model.Project

@Composable
fun HomeScreen(vm: AppViewModel) {
    val actions = rememberApkActions(vm)
    var deleteProject by remember { mutableStateOf<Project?>(null) }
    var deleteApk by remember { mutableStateOf<BuiltApk?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(Modifier.padding(vertical = 8.dp)) {
                Text("HTML to APK Studio", color = Palette.TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Helper("Turn a web page into an installable, signed Android app, entirely on this phone.")
            }
        }
        item {
            Button(
                onClick = { vm.startNew() },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.OnAccent)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("New Project", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        item { SectionTitle("Projects", Modifier.padding(top = 12.dp)) }
        if (vm.projects.isEmpty()) {
            item { Helper("No projects yet. Tap “New Project” to create your first app.") }
        } else {
            items(vm.projects, key = { it.id }) { p ->
                StudioCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 20.dp, top = 16.dp, bottom = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.appName.ifBlank { "Untitled" }, color = Palette.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Helper(p.packageName)
                            Helper("v${p.versionName} (${p.versionCode}) · ${formatDate(p.updatedAt)}")
                        }
                        IconButton(onClick = { vm.open(p) }) { Icon(Icons.Filled.Edit, "Open", tint = Palette.Accent) }
                        IconButton(onClick = { deleteProject = p }) { Icon(Icons.Filled.Delete, "Delete", tint = Palette.TextSecondary) }
                    }
                }
            }
        }

        item { SectionTitle("Built APKs", Modifier.padding(top = 12.dp)) }
        if (vm.apks.isEmpty()) {
            item { Helper("APKs you build appear here, ready to install or share.") }
        } else {
            items(vm.apks, key = { it.fileName }) { a ->
                StudioCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp)) {
                        Text(a.appName, color = Palette.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Helper("v${a.versionName} (${a.versionCode}) · ${formatSize(a.sizeBytes)}")
                        Helper(formatDate(a.createdAt))
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = { actions.install(a) },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.OnAccent)
                            ) {
                                Icon(Icons.Filled.SystemUpdate, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Install")
                            }
                            OutlinedButton(onClick = { actions.share(a) }, shape = CircleShape) {
                                Icon(Icons.Filled.Share, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Share")
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { deleteApk = a }) { Icon(Icons.Filled.Delete, "Delete", tint = Palette.TextSecondary) }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    deleteProject?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteProject = null },
            containerColor = Palette.Card,
            title = { Text("Delete project?", color = Palette.TextPrimary) },
            text = { Text("“${p.appName.ifBlank { "Untitled" }}” and its files will be removed. Built APKs are kept.", color = Palette.TextSecondary) },
            confirmButton = { TextButton(onClick = { vm.deleteProject(p); deleteProject = null }) { Text("Delete", color = Palette.Error) } },
            dismissButton = { TextButton(onClick = { deleteProject = null }) { Text("Cancel", color = Palette.TextSecondary) } }
        )
    }
    deleteApk?.let { a ->
        AlertDialog(
            onDismissRequest = { deleteApk = null },
            containerColor = Palette.Card,
            title = { Text("Delete APK?", color = Palette.TextPrimary) },
            text = { Text("${a.fileName} will be deleted from this phone.", color = Palette.TextSecondary) },
            confirmButton = { TextButton(onClick = { vm.deleteApk(a); deleteApk = null }) { Text("Delete", color = Palette.Error) } },
            dismissButton = { TextButton(onClick = { deleteApk = null }) { Text("Cancel", color = Palette.TextSecondary) } }
        )
    }
}
