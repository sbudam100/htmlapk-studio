package com.htmlapk.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.htmlapk.studio.data.HtmlAnalyzer
import com.htmlapk.studio.data.HtmlReport
import com.htmlapk.studio.model.Orientation
import com.htmlapk.studio.model.Permissions
import com.htmlapk.studio.model.Project
import com.htmlapk.studio.model.Rules
import com.htmlapk.studio.model.SourceType
import com.htmlapk.studio.model.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------------------------------------ Step 1

@Composable
fun InfoStep(vm: AppViewModel, p: Project) {
    SectionTitle("App Information")
    Gap(12)
    StudioField(
        label = "App Name",
        value = p.appName,
        onValueChange = { v ->
            vm.update { it.copy(appName = v, packageName = if (it.packageEdited) it.packageName else Rules.defaultPackage(v)) }
        },
        helper = "This is what users will see under your app icon."
    )
    Gap(4)
    StudioField(
        label = "Package Name",
        value = p.packageName,
        onValueChange = { v -> vm.update { it.copy(packageName = v.lowercase().filter { c -> !c.isWhitespace() }, packageEdited = true) } },
        helper = "A unique ID like com.yourname.yourapp. Use only lowercase letters and dots.",
        error = if ((p.packageEdited || p.appName.isNotBlank()) && !Rules.isValidPackage(p.packageName)) "Not a valid package name (e.g. com.example.app)" else null
    )
    Gap(4)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StudioField(
            label = "Version Code",
            value = p.versionCode,
            onValueChange = { v -> vm.update { it.copy(versionCode = v.filter(Char::isDigit).take(9)) } },
            modifier = Modifier.weight(1f),
            keyboardType = KeyboardType.Number,
            error = Rules.versionCodeError(p)
        )
        StudioField(
            label = "Version Name",
            value = p.versionName,
            onValueChange = { v -> vm.update { it.copy(versionName = v.take(30)) } },
            modifier = Modifier.weight(1f),
            error = if (p.versionName.isBlank()) "Required" else null
        )
    }
    Helper("Version code is a number. Increase it for every update (e.g. 1, 2, 3…). Version name is what users see (e.g. 1.0, 1.1, 2.0).")
    Gap(6)
    CheckRow(
        title = "Auto-increment version code",
        subtitle = "Automatically increase version code on each build",
        checked = p.autoIncrement,
        onChange = { v -> vm.update { it.copy(autoIncrement = v) } }
    )
    Gap(8)
    StudioField(
        label = "Min SDK",
        value = p.minSdk,
        onValueChange = { v -> vm.update { it.copy(minSdk = v.filter(Char::isDigit).take(2)) } },
        keyboardType = KeyboardType.Number,
        helper = "The oldest Android version your app supports. 24 = Android 7.0.",
        extraHelper = Rules.androidName(p.minSdk.toIntOrNull()).ifEmpty { null },
        error = Rules.minSdkError(p)
    )
    Gap(4)
    StudioField(
        label = "Target SDK",
        value = p.targetSdk,
        onValueChange = { v -> vm.update { it.copy(targetSdk = v.filter(Char::isDigit).take(2)) } },
        keyboardType = KeyboardType.Number,
        helper = "The Android version your app is designed for. 36 = Android 16.",
        extraHelper = Rules.androidName(p.targetSdk.toIntOrNull()).ifEmpty { null },
        error = Rules.targetSdkError(p)
    )
    Gap(4)
    StudioField(
        label = "Max SDK (optional)",
        value = p.maxSdk,
        onValueChange = { v -> vm.update { it.copy(maxSdk = v.filter(Char::isDigit).take(2)) } },
        keyboardType = KeyboardType.Number,
        helper = "Leave empty unless you want to block newer Android versions.",
        extraHelper = Rules.androidName(p.maxSdk.toIntOrNull()).ifEmpty { null },
        error = Rules.maxSdkError(p)
    )
    Gap(4)
    StudioField(
        label = "Custom URL Scheme (optional)",
        value = p.customScheme,
        onValueChange = { v -> vm.update { it.copy(customScheme = v.lowercase().filter { c -> !c.isWhitespace() }.take(30)) } },
        helper = "Example: myapp → opens myapp://anything",
        error = if (!Rules.isValidScheme(p.customScheme)) "Letters, digits, + . - only; must start with a letter" else null
    )
}

// ------------------------------------------------------------------------------------------------ Step 2

@Composable
fun ContentStep(vm: AppViewModel, p: Project) {
    val htmlPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importHtml(uri)
    }
    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importZip(uri)
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.importFolder(uri)
    }

    SectionTitle("Content Source")
    Gap(12)
    DropdownField(
        label = "Source Type",
        options = SourceType.entries.map { it.label },
        selectedIndex = p.sourceType.ordinal,
        onSelect = { vm.setSourceType(SourceType.entries[it]) }
    )
    Gap(8)

    when (p.sourceType) {
        SourceType.HTML -> {
            ActionButton("Select HTML File", Icons.Filled.UploadFile, filled = true) {
                htmlPicker.launch(arrayOf("text/html", "application/xhtml+xml", "text/plain", "*/*"))
            }
            Gap(8)
            if (p.hasContent) Text("Selected: ${p.contentName}", color = Palette.TextPrimary, fontSize = 15.sp)
            else Helper("Required. Choose the .html file of your app.")
        }
        SourceType.ZIP -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Select ZIP", Icons.Filled.UploadFile, filled = true, modifier = Modifier.weight(1f)) {
                    zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"))
                }
                ActionButton("Select Folder", Icons.Filled.FolderOpen, filled = false, modifier = Modifier.weight(1f)) {
                    folderPicker.launch(null)
                }
            }
            Gap(8)
            if (p.hasContent) {
                Text("Selected: ${p.contentName}", color = Palette.TextPrimary, fontSize = 15.sp)
                Gap(8)
                val options = vm.entryCandidates.ifEmpty { listOf(p.entryFile) }
                DropdownField(
                    label = "Entry file",
                    options = options,
                    selectedIndex = options.indexOf(p.entryFile).coerceAtLeast(0),
                    onSelect = { i -> vm.update { it.copy(entryFile = options[i]) } },
                    helper = "The page that opens first (default index.html)."
                )
            } else Helper("Required. Pick a ZIP archive or a folder that contains your web files.")
        }
        SourceType.URL -> {
            StudioField(
                label = "Website URL",
                value = p.websiteUrl,
                onValueChange = { v -> vm.update { it.copy(websiteUrl = v.trim()) } },
                keyboardType = KeyboardType.Uri,
                placeholder = "https://example.com",
                helper = "The app loads this address. Internet permission is added automatically.",
                error = if (p.websiteUrl.isNotEmpty()) Rules.urlError(p) else null
            )
        }
    }

    if (Rules.contentValid(p)) {
        Gap(12)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("Preview", Icons.Filled.PlayArrow, filled = false, modifier = Modifier.weight(1f)) {
                vm.screen = Screen.PREVIEW
            }
            if (p.sourceType != SourceType.URL) {
                ActionButton("Edit HTML", Icons.Filled.Code, filled = false, modifier = Modifier.weight(1f)) {
                    vm.screen = Screen.EDITOR
                }
            }
        }
    }

    if (p.hasContent && p.sourceType != SourceType.URL) {
        var report by remember { mutableStateOf<HtmlReport?>(null) }
        LaunchedEffect(vm.contentVersion, p.entryFile, p.sourceType, p.hasContent) {
            val file = vm.editableFile()
            report = if (file != null) withContext(Dispatchers.IO) { HtmlAnalyzer.analyzeFile(file) } else null
        }
        report?.let {
            Gap(16)
            StatusBox(it.ok, it.messages)
        }
    }
}

@Composable
fun ActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    filled: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val content: @Composable () -> Unit = {
        Icon(icon, null, Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, maxLines = 1)
    }
    if (filled) {
        Button(
            onClick = onClick, enabled = enabled, shape = CircleShape,
            modifier = modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = Palette.Accent, contentColor = Palette.OnAccent,
                disabledContainerColor = Palette.Disabled, disabledContentColor = Palette.TextSecondary
            )
        ) { content() }
    } else {
        OutlinedButton(
            onClick = onClick, enabled = enabled, shape = CircleShape, modifier = modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Palette.TextPrimary)
        ) { content() }
    }
}

// ------------------------------------------------------------------------------------------------ Step 3

private val barColors = listOf(
    0xFF000000.toInt(), 0xFF212121.toInt(), 0xFFFFFFFF.toInt(), 0xFF2196F3.toInt(), 0xFF334155.toInt(), 0xFF009688.toInt()
)
private val loadingColors = listOf(0xFFFFFFFF.toInt(), 0xFFE5E7EB.toInt(), 0xFF1E1E1E.toInt(), 0xFF000000.toInt())

@Composable
fun DisplayStep(vm: AppViewModel, p: Project) {
    var colorsOpen by remember { mutableStateOf(true) }
    SectionTitle("Display Settings")
    Gap(12)
    DropdownField(
        label = "Orientation",
        options = Orientation.entries.map { it.label },
        selectedIndex = p.orientation.ordinal,
        onSelect = { i -> vm.update { it.copy(orientation = Orientation.entries[i]) } }
    )
    Gap(8)
    CheckRow("Show status bar", p.statusBarVisible, { v -> vm.update { it.copy(statusBarVisible = v) } })
    CheckRow("Show action bar", p.actionBarVisible, { v -> vm.update { it.copy(actionBarVisible = v) } }, subtitle = "Keep the app title bar visible")
    CheckRow("Keep screen on", p.keepScreenOn, { v -> vm.update { it.copy(keepScreenOn = v) } })
    CheckRow(
        "Show camera cutout", p.cutout, { v -> vm.update { it.copy(cutout = v) } },
        subtitle = "Allow content to extend into the camera notch or punch hole area"
    )
    CheckRow(
        "Desktop mode", p.desktopMode, { v -> vm.update { it.copy(desktopMode = v) } },
        subtitle = "Load web pages in desktop browser layout"
    )
    Gap(8)

    Row(
        Modifier.fillMaxWidth().clickable { colorsOpen = !colorsOpen }.padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Colors", color = Palette.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Icon(if (colorsOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null, tint = Palette.Accent)
    }
    if (colorsOpen) {
        Text("Website theme", color = Palette.TextPrimary, fontSize = 15.sp)
        Gap(6)
        SegmentedRow(
            options = ThemeMode.entries.map { it.label },
            selectedIndex = p.themeMode.ordinal,
            onSelect = { i -> vm.update { it.copy(themeMode = ThemeMode.entries[i]) } }
        )
        Gap(16)
        Text("Status and navigation bar color", color = Palette.TextPrimary, fontSize = 15.sp)
        Helper("Both bars share one color.")
        Gap(8)
        SwatchRow(barColors, p.barColor, { c -> vm.update { it.copy(barColor = c) } }, allowCustom = true)
        Gap(16)
        Text("Loading background", color = Palette.TextPrimary, fontSize = 15.sp)
        Helper("Shown while your page loads.")
        Gap(8)
        SwatchRow(loadingColors, p.loadingBackground, { c -> vm.update { it.copy(loadingBackground = c) } }, allowCustom = true)
    }
}

// ------------------------------------------------------------------------------------------------ Step 4

@Composable
fun PermissionsStep(vm: AppViewModel, p: Project) {
    SectionTitle("Permissions")
    Gap(4)
    Helper("Only select what your app needs. More permissions = less user trust.")
    Gap(8)
    Permissions.all.forEach { def ->
        val forced = def.id == "android.permission.INTERNET" && p.sourceType == SourceType.URL
        CheckRow(
            title = def.title,
            subtitle = def.description + if (forced) " (required for a website URL)" else "",
            extra = def.id.removePrefix("android.permission.").let { "android.permission.$it" },
            checked = forced || def.id in p.permissions,
            enabled = !forced,
            onChange = { on ->
                vm.update { cur -> cur.copy(permissions = if (on) cur.permissions + def.id else cur.permissions - def.id) }
            }
        )
    }
}
