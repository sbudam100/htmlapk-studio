package com.htmlapk.studio.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.htmlapk.studio.data.DistinguishedName
import com.htmlapk.studio.data.KeystoreInfo

@Composable
fun KeystoreScreen(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.reloadKeystores() }
    var showCreate by remember { mutableStateOf(false) }
    var importUri by remember { mutableStateOf<Uri?>(null) }
    var details by remember { mutableStateOf<KeystoreInfo?>(null) }
    var exportTarget by remember { mutableStateOf<KeystoreInfo?>(null) }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importUri = uri
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val info = exportTarget
        exportTarget = null
        if (uri != null && info != null) vm.exportKeystore(info, uri)
    }

    BackHandler { vm.screen = Screen.WIZARD }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.WIZARD }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Palette.TextPrimary)
            }
            Text("Manage Keystore", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("Create new", Icons.Filled.Add, filled = true, modifier = Modifier.weight(1f)) { showCreate = true }
            ActionButton("Import", Icons.Filled.UploadFile, filled = false, modifier = Modifier.weight(1f)) {
                importPicker.launch(arrayOf("*/*"))
            }
        }
        Helper(
            "Apps are signed with the selected keystore. Use the same keystore for every update of an app, otherwise Android will refuse to install it over the old version.",
            Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vm.keystores, key = { it.id }) { ks ->
                StudioCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 20.dp, top = 14.dp, bottom = 14.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(ks.name, color = Palette.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Helper("Alias: ${ks.alias} · ${ks.type}")
                            Helper("Valid until ${java.text.DateFormat.getDateInstance().format(java.util.Date(ks.validUntil))}")
                        }
                        IconButton(onClick = { details = ks }) { Icon(Icons.Filled.Info, "Details", tint = Palette.Accent) }
                    }
                }
            }
        }
    }

    if (showCreate) CreateKeystoreDialog(onDismiss = { showCreate = false }) { name, alias, pass, years, dn ->
        showCreate = false
        vm.createKeystore(name, alias, pass, years, dn)
    }

    importUri?.let { uri ->
        ImportKeystoreDialog(onDismiss = { importUri = null }) { name, alias, sp, kp ->
            importUri = null
            vm.importKeystore(uri, name, alias, sp, kp)
        }
    }

    details?.let { ks ->
        KeystoreDetailsDialog(
            vm = vm, info = ks,
            onDismiss = { details = null },
            onExport = {
                exportTarget = ks
                details = null
                exportPicker.launch("${ks.name.replace(Regex("[^A-Za-z0-9._-]+"), "_")}.${if (ks.type == "BKS") "bks" else "p12"}")
            },
            onDelete = { vm.deleteKeystore(ks); details = null }
        )
    }
}

@Composable
private fun CreateKeystoreDialog(
    onDismiss: () -> Unit,
    onCreate: (String, String, String, Int, DistinguishedName) -> Unit
) {
    var name by remember { mutableStateOf("My keystore") }
    var alias by remember { mutableStateOf("key0") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var years by remember { mutableStateOf("30") }
    var cn by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var ou by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var state by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("") }

    val yearsInt = years.toIntOrNull()
    val error = when {
        name.isBlank() -> "Enter a name"
        alias.isBlank() -> "Enter an alias"
        pass.length < 6 -> "Password needs at least 6 characters"
        pass != pass2 -> "Passwords do not match"
        yearsInt == null || yearsInt !in 1..100 -> "Validity must be 1–100 years"
        else -> null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Card,
        title = { Text("Create keystore", color = Palette.TextPrimary) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                StudioField("Name", name, { name = it })
                StudioField("Alias", alias, { alias = it.filter { c -> !c.isWhitespace() } })
                StudioField("Password", pass, { pass = it }, helper = "Used for the keystore and the key", visual = true)
                StudioField("Confirm password", pass2, { pass2 = it }, visual = true)
                StudioField("Validity (years)", years, { years = it.filter(Char::isDigit).take(3) }, keyboardType = KeyboardType.Number)
                StudioField("Your name (CN)", cn, { cn = it })
                StudioField("Organization (O)", org, { org = it })
                StudioField("Organizational unit (OU)", ou, { ou = it })
                StudioField("City (L)", city, { city = it })
                StudioField("State (ST)", state, { state = it })
                StudioField("Country code (C)", country, { country = it.take(2) })
                if (error != null) Text(error, color = Palette.Error, fontSize = 13.sp)
            }
        },
        confirmButton = {
            TextButton(
                enabled = error == null,
                onClick = { onCreate(name.trim(), alias.trim(), pass, yearsInt ?: 30, DistinguishedName(cn.trim(), org.trim(), ou.trim(), city.trim(), state.trim(), country.trim())) }
            ) { Text("Create", color = if (error == null) Palette.Accent else Palette.TextSecondary) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.TextSecondary) } }
    )
}

@Composable
private fun ImportKeystoreDialog(onDismiss: () -> Unit, onImport: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var alias by remember { mutableStateOf("") }
    var storePass by remember { mutableStateOf("") }
    var keyPass by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Card,
        title = { Text("Import keystore", color = Palette.TextPrimary) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Helper("Supports .p12 / .pfx / .jks (PKCS12 format) and .bks files.")
                Gap(8)
                StudioField("Display name (optional)", name, { name = it })
                StudioField("Key alias (optional)", alias, { alias = it }, helper = "Leave empty to use the first key")
                StudioField("Keystore password", storePass, { storePass = it }, visual = true)
                StudioField("Key password (optional)", keyPass, { keyPass = it }, helper = "Leave empty if same as keystore password", visual = true)
            }
        },
        confirmButton = {
            TextButton(enabled = storePass.isNotEmpty(), onClick = { onImport(name.trim(), alias.trim(), storePass, keyPass) }) {
                Text("Import", color = if (storePass.isNotEmpty()) Palette.Accent else Palette.TextSecondary)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.TextSecondary) } }
    )
}

@Composable
private fun KeystoreDetailsDialog(
    vm: AppViewModel,
    info: KeystoreInfo,
    onDismiss: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    var reveal by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val passwords = remember(info.id, reveal) {
        if (reveal) try { vm.keystoreRepo.passwords(info) } catch (e: Exception) { null } else null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Card,
        title = { Text(info.name, color = Palette.TextPrimary) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                DetailLine("Alias", info.alias)
                DetailLine("Type", info.type)
                DetailLine("Subject", info.subject)
                DetailLine("Valid until", java.text.DateFormat.getDateInstance().format(java.util.Date(info.validUntil)))
                if (info.isDefault) Helper("The default keystore is created automatically and reused for every build. It cannot be deleted. Export it to keep a backup.")
                Gap(8)
                if (reveal && passwords != null) {
                    DetailLine("Keystore password", passwords.first)
                    DetailLine("Key password", passwords.second)
                } else {
                    TextButton(onClick = { reveal = true }) { Text("Show passwords", color = Palette.Accent) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onExport) { Text("Export", color = Palette.Accent) } },
        dismissButton = {
            Row {
                if (!info.isDefault) TextButton(onClick = { confirmDelete = true }) { Text("Delete", color = Palette.Error) }
                TextButton(onClick = onDismiss) { Text("Close", color = Palette.TextSecondary) }
            }
        }
    )
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = Palette.Card,
            title = { Text("Delete keystore?", color = Palette.TextPrimary) },
            text = { Text("Apps signed with it can no longer be updated by new builds unless you import it again.", color = Palette.TextSecondary) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Delete", color = Palette.Error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = Palette.TextSecondary) } }
        )
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, color = Palette.TextSecondary, fontSize = 12.sp)
        androidx.compose.foundation.text.selection.SelectionContainer {
            Text(value, color = Palette.TextPrimary, fontSize = 15.sp)
        }
    }
}
