package com.htmlapk.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.htmlapk.studio.build.BuildStage

@Composable
fun BuildScreen(vm: AppViewModel) {
    // Keep the screen on for the whole build.
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        when (val state = vm.buildState) {
            is BuildUiState.Running -> RunningView(vm, state)
            is BuildUiState.Failed -> FailedView(vm, state)
            is BuildUiState.Success -> SuccessView(vm, state)
            BuildUiState.Idle -> Unit
        }
    }
}

@Composable
private fun ColumnScope.RunningView(vm: AppViewModel, state: BuildUiState.Running) {
    StudioCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp)) {
            SectionTitle("Building your APK…")
            Helper("Keep this screen open. It stays awake until the build finishes.")
            Gap(16)
            BuildStage.entries.forEach { stage ->
                val done = stage.ordinal < state.stage.ordinal
                val current = stage == state.stage
                Row(Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
                        when {
                            done -> Icon(Icons.Filled.CheckCircle, null, tint = Palette.Success)
                            current -> CircularProgressIndicator(Modifier.size(22.dp), color = Palette.Accent, strokeWidth = 3.dp)
                            else -> Icon(Icons.Filled.RadioButtonUnchecked, null, tint = Palette.Outline)
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        stage.label,
                        color = if (done || current) Palette.TextPrimary else Palette.TextSecondary,
                        fontSize = 17.sp,
                        fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
    Spacer(Modifier.weight(1f))
    OutlinedButton(
        onClick = { vm.cancelBuild() },
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = CircleShape
    ) { Text("Cancel", color = Palette.TextPrimary, fontSize = 16.sp) }
}

@Composable
private fun ColumnScope.FailedView(vm: AppViewModel, state: BuildUiState.Failed) {
    val clipboard = LocalClipboardManager.current
    val logText = state.log.joinToString("\n")
    StudioCard(Modifier.fillMaxWidth().weight(1f)) {
        Column(Modifier.padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Error, null, tint = Palette.Error)
                Spacer(Modifier.width(10.dp))
                Text("Build failed", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            Gap(8)
            Text(state.message, color = Palette.Error, fontSize = 15.sp)
            Gap(12)
            Text("Log", color = Palette.TextSecondary, fontSize = 13.sp)
            Gap(4)
            Box(
                Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)).background(Color0)
                    .verticalScroll(rememberScrollState()).padding(12.dp)
            ) {
                SelectionContainer {
                    Text(logText, color = Palette.TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(
            onClick = { clipboard.setText(AnnotatedString(logText)); vm.toast("Log copied") },
            modifier = Modifier.weight(1f).height(52.dp), shape = CircleShape
        ) {
            Icon(Icons.Filled.ContentCopy, null, Modifier.size(18.dp), tint = Palette.TextPrimary)
            Spacer(Modifier.width(8.dp))
            Text("Copy log", color = Palette.TextPrimary)
        }
        Button(
            onClick = { vm.leaveBuild() },
            modifier = Modifier.weight(1f).height(52.dp), shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.OnAccent)
        ) { Text("Back", fontWeight = FontWeight.SemiBold) }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color(0xFF101014)

@Composable
private fun ColumnScope.SuccessView(vm: AppViewModel, state: BuildUiState.Success) {
    val actions = rememberApkActions(vm)
    val apk = state.apk
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        StudioCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CheckCircle, null, tint = Palette.Success, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Your APK is ready", color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Gap(16)
                ResultLine("File", apk.fileName)
                ResultLine("Size", formatSize(apk.sizeBytes))
                ResultLine("Version", "${apk.versionName} (${apk.versionCode})")
                ResultLine("Package", apk.packageName)
                Gap(20)
                Button(
                    onClick = { actions.install(apk) },
                    modifier = Modifier.fillMaxWidth().height(54.dp), shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.OnAccent)
                ) {
                    Icon(Icons.Filled.SystemUpdate, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Install", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Gap(10)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { actions.share(apk) }, modifier = Modifier.weight(1f).height(50.dp), shape = CircleShape) {
                        Icon(Icons.Filled.Share, null, Modifier.size(18.dp), tint = Palette.TextPrimary)
                        Spacer(Modifier.width(6.dp))
                        Text("Share", color = Palette.TextPrimary)
                    }
                    OutlinedButton(onClick = { actions.saveToDownloads(apk) }, modifier = Modifier.weight(1f).height(50.dp), shape = CircleShape) {
                        Icon(Icons.Filled.Download, null, Modifier.size(18.dp), tint = Palette.TextPrimary)
                        Spacer(Modifier.width(6.dp))
                        Text("Save", color = Palette.TextPrimary, maxLines = 1)
                    }
                }
                Helper("“Save” puts a copy into your Downloads folder.", Modifier.padding(top = 6.dp))
            }
        }
        Gap(12)
        Text("Build log", color = Palette.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
        Gap(4)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color0).padding(14.dp)) {
            Text(state.log.joinToString("\n"), color = Palette.TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = { vm.leaveBuild() }, modifier = Modifier.weight(1f).height(52.dp), shape = CircleShape) {
            Text("Build again", color = Palette.TextPrimary, fontSize = 16.sp)
        }
        TextButton(onClick = { vm.leaveBuild(); vm.exitWizard() }, modifier = Modifier.weight(1f).height(52.dp)) {
            Text("Home", color = Palette.Accent, fontSize = 16.sp)
        }
    }
}

@Composable
private fun ResultLine(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, color = Palette.TextSecondary, fontSize = 12.sp)
        Text(value, color = Palette.TextPrimary, fontSize = 16.sp)
    }
}
