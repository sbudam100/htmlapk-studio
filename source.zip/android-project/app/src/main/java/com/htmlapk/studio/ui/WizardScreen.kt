package com.htmlapk.studio.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun WizardScreen(vm: AppViewModel) {
    val p = vm.draft ?: return
    val step = vm.step
    val valid = vm.stepValid(step, p)
    val last = step == Steps.COUNT - 1
    val percent = (step + 1) * 100 / Steps.COUNT

    Column(Modifier.fillMaxSize()) {
        // Top bar: back arrow + title
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.exitWizard() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close", tint = Palette.TextPrimary)
            }
            Text("New Project", color = Palette.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }

        // Step label + percentage + thin progress bar
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Step ${step + 1} / ${Steps.COUNT} · ${Steps.names[step]}",
                color = Palette.Accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
            )
            Text("$percent%", color = Palette.TextSecondary, fontSize = 14.sp)
        }
        LinearProgressIndicator(
            progress = { (step + 1).toFloat() / Steps.COUNT },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp).height(4.dp),
            color = Palette.Accent,
            trackColor = Palette.Outline,
            strokeCap = StrokeCap.Round
        )

        // Scrollable card; the bottom buttons below stay fixed.
        StudioCard(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
            key(step) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
                    when (step) {
                        Steps.INFO -> InfoStep(vm, p)
                        Steps.CONTENT -> ContentStep(vm, p)
                        Steps.DISPLAY -> DisplayStep(vm, p)
                        Steps.PERMISSIONS -> PermissionsStep(vm, p)
                        Steps.ICON -> IconStep(vm, p)
                        Steps.SPLASH -> SplashStep(vm, p)
                        Steps.WEBVIEW -> WebViewStep(vm, p)
                        Steps.SUMMARY -> SummaryStep(vm, p)
                        Steps.OUTPUT -> OutputStep(vm, p)
                    }
                }
            }
        }

        // Bottom buttons
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (step > 0) {
                OutlinedButton(
                    onClick = { vm.back() },
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = CircleShape
                ) { Text("Back", color = Palette.TextPrimary, fontSize = 16.sp) }
            }
            if (!last) {
                Button(
                    onClick = { vm.next() },
                    enabled = valid,
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Palette.Accent, contentColor = Palette.OnAccent,
                        disabledContainerColor = Palette.Disabled, disabledContentColor = Palette.TextSecondary
                    )
                ) { Text("Next", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}
