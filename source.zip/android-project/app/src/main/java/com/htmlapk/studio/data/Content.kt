package com.htmlapk.studio.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.IOException
import java.util.zip.ZipInputStream

/** Result of the "HTML structure" check shown on the Content step. */
data class HtmlReport(val ok: Boolean, val messages: List<String>)

object HtmlAnalyzer {
    private const val MAX_READ = 6 * 1024 * 1024

    fun analyze(html: String): HtmlReport {
        val warnings = mutableListOf<String>()
        if (!Regex("<html[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(html)) warnings += "Missing <html> tag"
        if (!Regex("<head[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(html)) warnings += "Missing <head> tag"
        if (!Regex("<body[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(html)) warnings += "Missing <body> tag"
        if (!Regex("<meta[^>]+name\\s*=\\s*[\"']?viewport", RegexOption.IGNORE_CASE).containsMatchIn(html)) {
            warnings += "Missing viewport meta tag (the page may look zoomed out on phones)"
        }
        return if (warnings.isEmpty()) HtmlReport(true, listOf("HTML structure looks good")) else HtmlReport(false, warnings)
    }

    fun analyzeFile(file: File): HtmlReport {
        if (!file.isFile) return HtmlReport(false, listOf("File not found"))
        return try {
            val len = minOf(file.length(), MAX_READ.toLong()).toInt()
            val buf = ByteArray(len)
            file.inputStream().use { var off = 0; while (off < len) { val n = it.read(buf, off, len - off); if (n < 0) break; off += n } }
            analyze(String(buf, Charsets.UTF_8))
        } catch (e: Exception) {
            HtmlReport(false, listOf("Could not read file: ${e.message}"))
        }
    }
}

object ContentImporter {

    private const val MAX_TOTAL_BYTES = 800L * 1024 * 1024
    private const val MAX_ENTRIES = 20_000

    fun displayName(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i)?.let { return it }
                }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    private fun resetDir(dir: File) {
        dir.deleteRecursively()
        dir.mkdirs()
    }

    /** A single HTML file becomes www/index.html. */
    fun importHtml(context: Context, uri: Uri, www: File) {
        resetDir(www)
        val out = File(www, "index.html")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open the selected file" }
            out.outputStream().use { input.copyTo(it) }
        }
    }

    /** Extracts a ZIP into www/ (zip-slip safe, size capped). A single wrapping folder is flattened. */
    fun importZip(context: Context, uri: Uri, www: File): List<String> {
        resetDir(www)
        val rootCanonical = www.canonicalPath + File.separator
        var total = 0L
        var count = 0
        context.contentResolver.openInputStream(uri).use { raw ->
            requireNotNull(raw) { "Cannot open the selected ZIP" }
            ZipInputStream(raw.buffered()).use { zip ->
                while (true) {
                    val e = zip.nextEntry ?: break
                    if (++count > MAX_ENTRIES) throw IOException("ZIP has too many files")
                    val name = e.name.replace('\\', '/')
                    if (name.startsWith("__MACOSX/") || name.endsWith(".DS_Store")) continue
                    val target = File(www, name)
                    if (!target.canonicalPath.startsWith(rootCanonical)) throw IOException("Unsafe path in ZIP: $name")
                    if (e.isDirectory) { target.mkdirs(); continue }
                    target.parentFile?.mkdirs()
                    target.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = zip.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_TOTAL_BYTES) throw IOException("ZIP is too large (limit 800 MB)")
                            out.write(buf, 0, n)
                        }
                    }
                }
            }
        }
        flattenSingleRoot(www)
        return listHtmlFiles(www)
    }

    /** Copies a whole folder picked with the system folder picker (Storage Access Framework). */
    fun importFolder(context: Context, tree: Uri, www: File): List<String> {
        resetDir(www)
        val root = DocumentFile.fromTreeUri(context, tree) ?: throw IOException("Cannot open the folder")
        var total = 0L
        var count = 0
        fun copy(doc: DocumentFile, into: File) {
            for (child in doc.listFiles()) {
                val name = child.name ?: continue
                if (name.startsWith(".")) continue
                if (child.isDirectory) {
                    val d = File(into, name)
                    d.mkdirs()
                    copy(child, d)
                } else if (child.isFile) {
                    if (++count > MAX_ENTRIES) throw IOException("Folder has too many files")
                    total += child.length()
                    if (total > MAX_TOTAL_BYTES) throw IOException("Folder is too large (limit 800 MB)")
                    context.contentResolver.openInputStream(child.uri).use { input ->
                        requireNotNull(input) { "Cannot read $name" }
                        File(into, name).outputStream().use { input.copyTo(it) }
                    }
                }
            }
        }
        copy(root, www)
        return listHtmlFiles(www)
    }

    private fun flattenSingleRoot(www: File) {
        val children = www.listFiles() ?: return
        if (children.size == 1 && children[0].isDirectory) {
            val inner = children[0]
            val tmp = File(www.parentFile, "www_tmp_${System.nanoTime()}")
            if (inner.renameTo(tmp)) {
                www.deleteRecursively()
                tmp.renameTo(www)
            }
        }
    }

    /** Relative paths (with '/') of every .html/.htm file, shallowest and "index.html" first. */
    fun listHtmlFiles(www: File): List<String> =
        www.walkTopDown()
            .filter { it.isFile && (it.extension.equals("html", true) || it.extension.equals("htm", true)) }
            .map { it.relativeTo(www).path.replace(File.separatorChar, '/') }
            .sortedWith(compareBy<String>({ !it.equals("index.html", true) }, { it.count { c -> c == '/' } }, { it }))
            .toList()
}
