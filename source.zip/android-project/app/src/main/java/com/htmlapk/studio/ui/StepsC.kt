package com.htmlapk.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.htmlapk.studio.data.KeystoreRepository
import com.htmlapk.studio.model.Project
import com.htmlapk.studio.model.Rules
import com.htmlapk.studio.model.SourceType

// ------------------------------------------------------------------------------------------------ Step 8 (Summary)

@Composable
fun SummaryStep(vm: AppViewModel, p: Project) {
    SectionTitle("Summary")
    Gap(4)
    Helper("Check everything, then continue to build. Tap the pencil to change a value.")
    Gap(12)

    val content = when (p.sourceType) {
        SourceType.HTML -> p.contentName.ifBlank { "Not selected" }
        SourceType.ZIP -> if (p.hasContent) "${p.contentName} · entry ${p.entryFile}" else "Not selected"
        SourceType.URL -> p.websiteUrl.ifBlank { "Not set" }
    }
    val yesNo = { b: Boolean -> if (b) "Yes" else "No" }
    val display = "${p.orientation.label} · Status: ${yesNo(p.statusBarVisible)} · Action: ${yesNo(p.actionBarVisible)} · " +
        "Keep on: ${yesNo(p.keepScreenOn)} · Color: ${Rules.hex(p.barColor)}"
    val permCount = Rules.effectivePermissions(p).size
    val permText = if (permCount == 1) "1 permission selected" else "$permCount permissions selected"
    val optCount = Rules.enabledWebOptions(p)
    val optText = if (optCount == 1) "1 option enabled" else "$optCount options enabled"
    val splash = when {
        !p.splash.enabled -> "Disabled"
        p.hasSplashImage -> "Custom"
        else -> "Default"
    }

    SummaryItem("App Name", p.appName.ifBlank { "—" }) { vm.goToStep(Steps.INFO) }
    SummaryItem("Package", p.packageName) { vm.goToStep(Steps.INFO) }
    SummaryItem("Version", "${p.versionName} (${p.versionCode})") { vm.goToStep(Steps.INFO) }
    SummaryItem("Content", content) { vm.goToStep(Steps.CONTENT) }
    SummaryItem("Display", display) { vm.goToStep(Steps.DISPLAY) }
    SummaryItem("Permissions", permText) { vm.goToStep(Steps.PERMISSIONS) }
    SummaryItem("Icon", if (p.hasIcon) "Selected" else "Default") { vm.goToStep(Steps.ICON) }
    SummaryItem("Splash", splash) { vm.goToStep(Steps.SPLASH) }
    SummaryItem("WebView Settings", optText) { vm.goToStep(Steps.WEBVIEW) }
}

@Composable
private fun SummaryItem(label: String, value: String, onEdit: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        shape = RoundedCornerShape(20.dp),
        color = Palette.CardHigh
    ) {
        Row(Modifier.padding(start = 18.dp, top = 12.dp, bottom = 12.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, color = Palette.TextSecondary, fontSize = 12.sp)
                Text(value, color = Palette.TextPrimary, fontSize = 16.sp, lineHeight = 22.sp)
            }
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Edit $label", tint = Palette.Accent) }
        }
    }
}

// ------------------------------------------------------------------------------------------------ Step 9 (Output)

@Composable
fun OutputStep(vm: AppViewModel, p: Project) {
    LaunchedEffect(Unit) { vm.reloadKeystores() }

    SectionTitle("Output Settings")
    Gap(12)
    Text("Format", color = Palette.TextPrimary, fontSize = 15.sp)
    Gap(6)
    SegmentedRow(options = listOf("APK", "AAB (Play Store)"), selectedIndex = 0, onSelect = {}, disabledIndexes = setOf(1))
    Helper("Not supported on-device yet.", Modifier.padding(top = 4.dp))
    Gap(16)

    val items = vm.keystores
    val labels = if (items.isEmpty()) listOf(KeystoreRepository.DEFAULT_LABEL) else items.map { it.name }
    val ids = if (items.isEmpty()) listOf(KeystoreRepository.DEFAULT_ID) else items.map { it.id }
    DropdownField(
        label = "Select Keystore",
        options = labels,
        selectedIndex = ids.indexOf(p.keystoreId).coerceAtLeast(0),
        onSelect = { i -> vm.update { it.copy(keystoreId = ids[i]) } },
        helper = "Always sign updates with the same keystore so they install over older versions."
    )
    Gap(8)
    ActionButton("Manage Keystore", Icons.Filled.Key, filled = false) { vm.screen = Screen.KEYSTORES }
    Gap(24)

    val ready = Rules.infoValid(p) && Rules.contentValid(p)
    if (!ready) {
        StatusBox(false, listOf("Some required information is missing. Go back to step 1 and step 2 and complete it."))
        Gap(12)
    }
    Button(
        onClick = { vm.startBuild() },
        enabled = ready,
        modifier = Modifier.fillMaxWidth().height(58.dp),
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = Palette.Accent, contentColor = Palette.OnAccent,
            disabledContainerColor = Palette.Disabled, disabledContentColor = Palette.TextSecondary
        )
    ) {
        Icon(Icons.Filled.Build, null, Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text("Build APK", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
    Gap(10)
    Text(
        "This process may take up to 1 minute, do not turn off your screen",
        color = Palette.TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
    )
}
