# HTML to APK Studio: PLAN

## 1. Architecture

Two Gradle modules, one repository, one command (`./gradlew assembleDebug`).

| Module | Role |
|---|---|
| `:template` | The **generated app's shell**: a tiny View-based `ShellActivity` (no Compose) that reads `assets/config.json` and builds everything at runtime. Its *unsigned release APK* is the "template". Kotlin namespace `com.htmlapk.shell`, placeholder applicationId `com.htmlapk.shell.template`. |
| `:app` | The **builder** (Kotlin, Compose, Material 3). Packages: `model` (Project, settings, permission table, validation `Rules`), `data` (project/APK repositories, content import, icon processing, keystores, `KeyTools`), `build` (pipeline), `ui` (screens, wizard steps, ViewModel). |

Data flow: **wizard** edits an immutable `Project` held in `AppViewModel` and saved as `project.json` + `www/` + `icon.png` + `splash.png` under `filesDir/projects/<id>/` → **Build APK** calls `ApkBuilder.build()` on `Dispatchers.IO` → `ApkAssembler` (patch manifest, add files, replace icons, align) → `ApkSigning` (apksig v1+v2+v3 then verify) → APK stored in `filesDir/apks/` with a metadata JSON → **result screen** (Install via `FileProvider` + `ACTION_VIEW`, Share, Save to Downloads via MediaStore).

**Wizard has 9 steps** (the reference app's Ads step is removed and the numbering is consistent everywhere): 1 Info · 2 Content · 3 Display · 4 Permissions · 5 Icon · 6 Splash · 7 WebView · 8 Summary · 9 Output. Everything is unlocked: no Pro locks, watermark or ads.

## 2. APK-generation strategy

1. **Template onto the phone.** `app/build.gradle.kts` registers `copyTemplateApk`, which depends on `:template:assembleRelease` and copies `template-release-unsigned.apk` into a *generated assets directory* of every variant as `assets/template.apk`. No manual step.
2. **Binary manifest patching (ARSCLib).** `ManifestPatcher` loads the compiled `AndroidManifest.xml` with `AndroidManifestBlock`, then sets package, versionCode/versionName, application label (literal string), min/target/max SDK, `uses-permission` entries (with `maxSdkVersion` where needed), `usesCleartextTraffic`, `debuggable=false`, and optionally adds a `VIEW/DEFAULT/BROWSABLE` intent-filter with `<data android:scheme>` to the launcher activity. ARSCLib rebuilds the string pool, resource-id map and chunk sizes. **Every attribute value starting with `<oldPackage>.`** (provider authorities, the generated `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`) is rewritten to the new package, so two generated apps never collide. The result is re-parsed and checked.
3. **Injecting files.** `AlignedZipWriter` writes a new ZIP: patched manifest, `assets/config.json`, `assets/www/**` (user files), optional `assets/splash_logo.png`, then all remaining template entries (old `META-INF` signature files are dropped).
4. **Icons.** The template ships plain PNG launcher icons (`res/mipmap-*dpi/ic_launcher.png` and `ic_launcher_round.png`; `android.enableResourceOptimizations=false` keeps these paths stable). The builder finds them by pattern and overwrites them with the user's image resized to 48/72/96/144/192 px (round variant circle-clipped).
5. **zipalign.** `AlignedZipWriter` pads STORED entries (via a `0xD935` extra field) so data starts on 4 bytes (4096 for `.so`). `resources.arsc` is always STORED. `verifyAlignment()` checks this before signing.
6. **Signing.** `com.android.tools.build:apksig` with the selected keystore: v1 + v2 + v3, then `ApkVerifier` must report success. (v1 entries are written; `apksigner verify` only checks them when the min SDK is below 24.)
7. **Installing.** Needs `REQUEST_INSTALL_PACKAGES`; `canRequestPackageInstalls()` is checked, otherwise the "Install unknown apps" settings page opens and installation continues when the user returns. The APK is handed over via `FileProvider` (`${applicationId}.fileprovider`) with `ACTION_VIEW` + `application/vnd.android.package-archive`.

## 3. Libraries (all verified to exist)

| Purpose | Coordinates |
|---|---|
| Android Gradle Plugin | `com.android.application` **8.10.1** (Gradle 8.13, JDK 17) |
| Kotlin / Compose compiler / serialization plugins | `org.jetbrains.kotlin.*` **2.1.21** |
| Compose BOM | `androidx.compose:compose-bom:2025.05.01` (Material 3, icons-extended) |
| Activity / Lifecycle / Core | `androidx.activity:activity(-compose):1.10.1`, `androidx.lifecycle:lifecycle-viewmodel-compose:2.9.0`, `androidx.core:core-ktx:1.16.0` |
| Coroutines / JSON | `org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2`, `kotlinx-serialization-json:1.8.0` |
| Binary XML | `io.github.reandroid:ARSCLib:1.3.5` (Maven Central) |
| Signing | `com.android.tools.build:apksig:8.10.1` |
| Certificates | `org.bouncycastle:bcprov-jdk18on:1.78.1`, `bcpkix-jdk18on:1.78.1` |
| WebView | `androidx.webkit:webkit:1.13.0` (template and builder preview) |
| Template UI | `androidx.swiperefreshlayout:swiperefreshlayout:1.1.0` |
| Folder import | `androidx.documentfile:documentfile:1.0.1` |
| Tests | `junit:junit:4.13.2` |

## 4. File tree

```
android-project/
├─ settings.gradle.kts  build.gradle.kts  gradle.properties  gradlew  gradlew.bat  PLAN.md
├─ gradle/ libs.versions.toml  wrapper/{gradle-wrapper.jar, gradle-wrapper.properties}
├─ template/                                  (generated app shell)
│  ├─ build.gradle.kts
│  └─ src/main/
│     ├─ AndroidManifest.xml
│     ├─ java/com/htmlapk/shell/ ShellActivity.kt  ShellConfig.kt  SplashOverlay.kt  Bridge.kt
│     └─ res/ mipmap-*dpi/ic_launcher(_round).png  values/{strings,themes}.xml  values-night/themes.xml  drawable/splash_empty.xml
└─ app/                                       (builder)
   ├─ build.gradle.kts
   └─ src/
      ├─ main/AndroidManifest.xml, res/ (icons, themes, file_paths.xml)
      ├─ main/java/com/htmlapk/studio/
      │  ├─ MainActivity.kt
      │  ├─ model/Models.kt
      │  ├─ data/ Storage.kt  Content.kt  IconProcessor.kt  Keystores.kt  KeyTools.kt
      │  ├─ build/ ManifestPatcher.kt  AlignedZipWriter.kt  ApkAssembler.kt  ApkBuilder.kt  ConfigWriter.kt  Installer.kt
      │  └─ ui/ AppViewModel.kt  Theme.kt  Components.kt  ApkActions.kt  HomeScreen.kt  WizardScreen.kt
      │         StepsA.kt  StepsB.kt  StepsC.kt  PreviewEditor.kt  BuildScreen.kt  KeystoreScreen.kt
      └─ test/ build/ApkPipelineTest.kt  data/KeyToolsTest.kt
```

## 5. `config.json` schema (writer: `ConfigWriter`, reader: `ShellConfig`)

```json
{
  "schemaVersion": 1,
  "appName": "Photo Editor", "packageName": "com.htmlapk.photoeditor", "versionName": "1.0", "versionCode": 1,
  "sourceType": "html | zip | url",
  "entryFile": "index.html",
  "startUrl": "",                               // only for sourceType "url"
  "orientation": "portrait | landscape | auto",
  "statusBarVisible": true, "actionBarVisible": false, "keepScreenOn": false, "cutout": false, "desktopMode": false,
  "themeMode": "auto | night | day",
  "barColor": "#2196F3", "loadingBackground": "#FFFFFF",
  "customScheme": "",
  "declaredPermissions": ["android.permission.INTERNET"],
  "splash": { "enabled": false, "backgroundColor": "#0F172A", "loaderColor": "#00E5CC", "loaderStyle": "ring | bar | none",
              "iconSizeDp": 120, "iconCornerDp": 16, "loaderSizeDp": 48, "spacingDp": 28, "durationMs": 2000,
              "thicknessDp": 4, "fadeMs": 400, "imageAsset": "" },
  "navigation": { "pullToRefresh": false, "noInternetDialog": false, "loadingIndicator": false,
                  "backHistory": true, "exitConfirm": true, "apiOnlyOwnPages": true },
  "webview": { "javaScript": true, "domStorage": true, "fileAccess": false, "contentAccess": false,
               "universalFileAccess": false, "fileAccessFromFileUrls": false, "builtInZoom": true, "wideViewport": true,
               "overviewMode": true, "geolocation": false,
               "cacheMode": "default | no_cache | cache_else_network | cache_only",
               "mixedContent": "compatibility | never | always" }
}
```

## 6. Risks and handling

| Risk | Handling |
|---|---|
| Binary XML editing | ARSCLib (maintained, rebuilds all chunks). Result re-parsed and compared; unit-tested against the real template and checked with `aapt2 dump badging`. |
| Zip alignment / arsc | Own single-pass writer; `verifyAlignment()`; confirmed with `zipalign -c -P 16 -v 4`. |
| Signing | apksig v1+v2+v3 followed by `ApkVerifier`; confirmed with `apksigner verify`. Default keystore (RSA 2048, 30 years) generated once, passwords sealed by an AndroidKeyStore AES-GCM key, reused for all builds so updates install over old ones. |
| Package-name clashes | Template uses fully-qualified class names; all `<oldPackage>.*` attribute values (authorities, permissions) are rewritten; no `FileProvider` in the template. |
| Resource path shortening hiding the icons | `android.enableResourceOptimizations=false`; the builder fails loudly if no launcher PNGs are found. |
| Scoped storage | Saves via MediaStore (no permission on Android 10+); `WRITE_EXTERNAL_STORAGE` is requested only on Android 9 and below, with a fallback to the app-specific folder. |
| Large HTML (~1 MB) | Files are streamed, never held fully in memory; editor uses a native `EditText` (not Compose text fields); icon decode is bounds-sampled. |
| Blob downloads in WebView | `DownloadListener` injects a one-off, token-gated script that reads the blob, streams base64 chunks to a native receiver, then saves via MediaStore. `data:` URLs are decoded natively; the `download="name.png"` attribute is captured by a document-start hook. |
| JS bridge exposure | With "Android API only on your own pages" the API is injected with `addDocumentStartJavaScript` + `addWebMessageListener`, restricted to the own origin and the main frame. On WebViews without these features it is not exposed at all. |
| Android 16 behaviour | Back handled through `OnBackPressedDispatcher` (predictive back); system bar colours drawn by the shell (edge-to-edge); orientation locks are ignored by the system on large screens (≥600dp). |
| Cannot be compiled by AI Studio's sandbox? | Verified here with JDK 17 + Android SDK 36: `./gradlew assembleDebug` and the JVM tests pass. |

## 7. Build-order checklist

1. `libs.versions.toml`, settings, root build → 2. `:template` (config, bridge, splash, activity, manifest, icons) → 3. `app/build.gradle.kts` (template copy task, deps) → 4. `model` → 5. `data` (+`KeyTools`) → 6. `build` (patcher, writer, assembler, builder, config writer, installer) → 7. ViewModel → 8. UI components and steps → 9. screens (home, wizard, preview/editor, build, keystores) → 10. unit tests → 11. `./gradlew :app:testDebugUnitTest assembleDebug`.
